import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // déjà installée avec supabase_flutter

/// Mode d'affichage : suit le téléphone par défaut ; le bouton lune/soleil de l'accueil le change et le mémorise.
final ValueNotifier<ThemeMode> themeMode = ValueNotifier(ThemeMode.system);

Future<void> loadTheme() async {
  try {
    final saved = (await SharedPreferences.getInstance()).getString('theme');
    themeMode.value = ThemeMode.values.firstWhere((m) => m.name == saved, orElse: () => ThemeMode.system);
  } catch (_) {}
}

Future<void> setThemeMode(ThemeMode m) async {
  themeMode.value = m;
  try {
    await (await SharedPreferences.getInstance()).setString('theme', m.name);
  } catch (_) {}
}
