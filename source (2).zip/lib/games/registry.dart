import 'package:flutter/material.dart';
import '../core/board_game.dart';
import 'awale.dart';
import 'chess.dart';
import 'connect4.dart';
import 'draughts.dart';
import 'ludo.dart';
import 'matches.dart';
import 'memory.dart';
import 'othello.dart';
import 'pig.dart';
import 'rps.dart';
import 'snakes.dart';
import 'tictactoe.dart';

/// Ordre d'affichage des catégories sur la page d'accueil.
const gameCategories = ['Alignement', 'Stratégie', 'Graines (mancala)', 'Parcours & hasard', 'Pour tous'];

/// Pour ajouter un jeu : créer sa classe (extends BoardGame) puis ajouter une ligne ici.
/// Le menu, le bot, le LAN et le mode en ligne suivent.
final List<GameDef> allGames = [
  GameDef(id: 'tictactoe', category: 'Alignement', title: 'Morpion', subtitle: 'Aligne 3 symboles', icon: Icons.grid_3x3, minPlayers: 2, maxPlayers: 2, create: TicTacToe.new),
  GameDef(id: 'connect4', category: 'Alignement', title: 'Puissance 4', subtitle: 'Aligne 4 jetons', icon: Icons.view_column, minPlayers: 2, maxPlayers: 2, create: ConnectFour.new),
  GameDef(id: 'othello', category: 'Stratégie', title: 'Othello', subtitle: 'Retourne les pions adverses', icon: Icons.circle, minPlayers: 2, maxPlayers: 2, create: Othello.new),
  GameDef(id: 'draughts', category: 'Stratégie', title: 'Dames', subtitle: 'Capture tous les pions adverses', icon: Icons.grid_on, minPlayers: 2, maxPlayers: 2, create: Draughts.new),
  GameDef(id: 'chess', category: 'Stratégie', title: 'Échecs', subtitle: 'Mets le roi adverse échec et mat', icon: Icons.castle, minPlayers: 2, maxPlayers: 2, create: Chess.new),
  GameDef(id: 'awale', category: 'Graines (mancala)', title: 'Awalé', subtitle: 'Capture plus de 24 graines', icon: Icons.blur_circular, minPlayers: 2, maxPlayers: 2, create: Awale.new),
  GameDef(id: 'snakes', category: 'Parcours & hasard', title: 'Serpents et échelles', subtitle: 'Course à la case 100 · 2 à 6 joueurs', icon: Icons.casino, minPlayers: 2, maxPlayers: 6, create: Snakes.new),
  GameDef(id: 'ludo', category: 'Parcours & hasard', title: 'Ludo', subtitle: 'Petits chevaux · 2 à 4 joueurs', icon: Icons.flag, minPlayers: 2, maxPlayers: 4, create: Ludo.new),
  GameDef(id: 'pig', category: 'Parcours & hasard', title: 'Le Cochon', subtitle: 'Jeu de dés, 100 points · 2 à 6 joueurs', icon: Icons.casino_outlined, minPlayers: 2, maxPlayers: 6, create: Pig.new),
  GameDef(id: 'memory', category: 'Pour tous', title: 'Mémoire', subtitle: 'Retrouve les paires · 2 à 6 joueurs', icon: Icons.psychology, minPlayers: 2, maxPlayers: 6, create: MemoryGame.new),
  GameDef(id: 'rps', category: 'Pour tous', title: 'Pierre-feuille-ciseaux', subtitle: 'Le premier à 3 manches gagne', icon: Icons.back_hand, minPlayers: 2, maxPlayers: 2, create: Rps.new),
  GameDef(id: 'matches', category: 'Pour tous', title: 'Allumettes', subtitle: 'Ne prends pas la dernière allumette', icon: Icons.local_fire_department, minPlayers: 2, maxPlayers: 2, create: Matches.new),
];

GameDef? gameById(String id) {
  for (final g in allGames) {
    if (g.id == id) return g;
  }
  return null;
}
