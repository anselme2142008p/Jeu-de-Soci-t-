import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';
import '../core/game_controller.dart';
import '../core/lan.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/chat.dart';
import '../core/online.dart';
import '../core/theme.dart';
import '../core/people.dart';
import '../core/social_service.dart';
import '../core/voice.dart';
import '../games/registry.dart';
import 'social.dart';

// ───────────────────────── Menu principal ─────────────────────────

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _startMulti(BuildContext context, GameDef def, int n, {required bool bots}) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => GameScreen(
        def: def,
        seats: bots ? [Seat.human, for (var i = 1; i < n; i++) Seat.bot] : [for (var i = 0; i < n; i++) Seat.human],
        names: bots ? ['Vous', for (var i = 2; i <= n; i++) 'Ordinateur $i'] : [for (var i = 1; i <= n; i++) 'Joueur $i'],
        botLevel: 2,
      ),
    ));
  }

  /// Jeux de plus de 2 joueurs : on choisit le nombre de joueurs, avec ou sans ordinateurs.
  void _pickMulti(BuildContext context, GameDef def) {
    var n = min(3, def.maxPlayers);
    showModalBottomSheet(
      context: context,
      builder: (sheet) => StatefulBuilder(
        builder: (ctx, setS) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(def.title, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                const Text('Nombre de joueurs'),
                const SizedBox(height: 6),
                Wrap(spacing: 8, children: [
                  for (var k = def.minPlayers; k <= def.maxPlayers; k++)
                    ChoiceChip(label: Text('$k'), selected: n == k, onSelected: (_) => setS(() => n = k)),
                ]),
                const SizedBox(height: 16),
                FilledButton.icon(
                  icon: const Icon(Icons.smart_toy),
                  label: const Text('Moi contre des ordinateurs'),
                  onPressed: () {
                    Navigator.of(sheet).pop();
                    _startMulti(context, def, n, bots: true);
                  },
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  icon: const Icon(Icons.people),
                  label: const Text('Entre amis, sur ce téléphone'),
                  onPressed: () {
                    Navigator.of(sheet).pop();
                    _startMulti(context, def, n, bots: false);
                  },
                ),
                const SizedBox(height: 10),
                Text('Les modes réseau local et en ligne à plus de 2 joueurs arrivent bientôt.', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _pickMode(BuildContext context, GameDef def) {
    if (def.maxPlayers > 2) {
      _pickMulti(context, def);
      return;
    }
    showModalBottomSheet(
      context: context,
      builder: (sheet) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(def.title,
                  style: Theme.of(context).textTheme.titleLarge),
            ),
            ListTile(
              leading: const Icon(Icons.smart_toy),
              title: const Text("Contre l'ordinateur"),
              subtitle: const Text('Hors ligne'),
              onTap: () {
                Navigator.of(sheet).pop();
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => GameScreen(
                    def: def,
                    seats: const [Seat.human, Seat.bot],
                    names: const ['Vous', 'Ordinateur'],
                    botLevel: 2,
                  ),
                ));
              },
            ),
            ListTile(
              leading: const Icon(Icons.people),
              title: const Text('À deux sur ce téléphone'),
              subtitle: const Text('Hors ligne'),
              onTap: () {
                Navigator.of(sheet).pop();
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => GameScreen(
                    def: def,
                    seats: const [Seat.human, Seat.human],
                    names: const ['Joueur 1', 'Joueur 2'],
                  ),
                ));
              },
            ),
            ListTile(
              leading: const Icon(Icons.wifi_tethering),
              title: const Text('Créer une partie (LAN)'),
              subtitle: const Text('Même Wi-Fi, sans internet'),
              onTap: () {
                Navigator.of(sheet).pop();
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => LanHostScreen(def: def),
                ));
              },
            ),
            ListTile(
              leading: const Icon(Icons.login),
              title: const Text('Rejoindre une partie (LAN)'),
              onTap: () {
                Navigator.of(sheet).pop();
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const LanJoinScreen(),
                ));
              },
            ),
            ListTile(
              leading: const Icon(Icons.public),
              title: const Text('En ligne'),
              subtitle: const Text('Avec ton compte, via internet'),
              onTap: () {
                Navigator.of(sheet).pop();
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => OnlineScreen(def: def),
                ));
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rotegan'),
        actions: [
          IconButton(
            tooltip: 'Mode sombre / clair',
            icon: Icon(Theme.of(context).brightness == Brightness.dark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => setThemeMode(Theme.of(context).brightness == Brightness.dark ? ThemeMode.light : ThemeMode.dark),
          ),
          IconButton(
            tooltip: 'Mon profil',
            icon: const Icon(Icons.account_circle),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileScreen())),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.smart_toy, size: 36),
              title: const Text('Joueurs IA'),
              subtitle: const Text('30 adversaires de nombreux pays'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AiPlayersScreen())),
            ),
          ),
          for (final cat in gameCategories)
            if (allGames.any((g) => g.category == cat)) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 18, 4, 6),
                child: Text(cat.toUpperCase(), style: Theme.of(context).textTheme.labelSmall),
              ),
              for (final g in allGames.where((g) => g.category == cat))
                Card(
                  child: ListTile(
                    leading: Icon(g.icon, size: 30),
                    title: Text(g.title),
                    subtitle: Text(g.subtitle),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _pickMode(context, g),
                  ),
                ),
            ],
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
            child: Text(
              'Bientôt : Dominos, Bataille navale, Pétanque, Billard, jeux de cartes',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── Écran de partie ─────────────────────────

class GameScreen extends StatefulWidget {
  final GameDef def;
  final List<Seat> seats;
  final List<String> names;
  final GameLink? lan;
  final PlayerInfo? me, opp;
  final int botLevel;
  final int? seed;

  const GameScreen({
    super.key,
    required this.def,
    required this.seats,
    required this.names,
    this.lan,
    this.me,
    this.opp,
    this.botLevel = 3,
    this.seed,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late GameController ctrl;
  PlayerInfo? me, opp;
  ChatChannel? chat;
  VoiceCall? call;

  @override
  void initState() {
    super.initState();
    me = widget.me;
    opp = widget.opp;
    ctrl = _make();
    final link = widget.lan;
    if (link is OnlineLink) {
      chat = OnlineChat(link.roomId);
      call = VoiceCall(link.roomId);
      Social.playersOf(link.roomId).then((p) {
        if (mounted) {
          setState(() {
            me = p[0];
            opp = p[1];
          });
        }
      }).catchError((_) {});
    } else if (widget.opp != null && widget.opp!.isBot) {
      chat = LlmBotChat(
        bot: widget.opp!,
        playerName: widget.me?.name ?? 'Joueur',
        gameContext: () => {
          'title': widget.def.title,
          'status': _status(),
          'move_count': ctrl.moveCount,
          'board': ctrl.game.describe(),
        },
      );
    }
  }

  String _name(int i) {
    if (opp != null && widget.seats[i] != Seat.human) return opp!.name;
    return widget.names[i];
  }

  GameController _make() {
    final g = widget.def.create();
    g.setPlayers(widget.seats.length);
    final link = widget.lan;
    if (widget.seed != null) {
      g.seed(widget.seed!);
    } else if (link is OnlineLink) {
      g.seed(link.roomId.codeUnits.fold<int>(0, (a, c) => (a * 31 + c) & 0x7fffffff));
    }
    final c = GameController(g, widget.seats, lan: widget.lan, botLevel: widget.botLevel);
    c.addListener(() => _maybeSaveScore(c));
    return c;
  }

  /// Une victoire contre l'ordinateur ou en ligne = 1 point dans la table scores.
  void _maybeSaveScore(GameController c) {
    if (!c.game.isOver || c.scoreSaved) return;
    c.scoreSaved = true;
    final bc = chat;
    if (bc is LlmBotChat) bc.reactToGameOver();
    final w = c.game.winner;
    final humans = widget.seats.where((s) => s == Seat.human).length;
    if (w != null && humans == 1 && widget.seats[w] == Seat.human) {
      OnlineService.saveWin(widget.def.id);
    }
  }

  @override
  void dispose() {
    chat?.dispose();
    call?.dispose();
    ctrl.dispose();
    super.dispose();
  }

  String _status() {
    final g = ctrl.game;
    if (ctrl.disconnected && !g.isOver) return 'Adversaire déconnecté';
    if (g.isOver) {
      final w = g.winner;
      return w == null ? 'Match nul !' : 'Victoire : ${_name(w)}';
    }
    return 'Au tour de : ${_name(g.currentPlayer)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.def.title),
        actions: [
          if (chat != null)
            IconButton(
              tooltip: 'Discuter',
              icon: const Icon(Icons.chat_bubble_outline),
              onPressed: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                builder: (_) => ChatSheet(chat: chat!),
              ),
            ),
          if (call != null) CallButton(call: call!),
        ],
      ),
      body: AnimatedBuilder(
        animation: ctrl,
        builder: (context, _) => Padding(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              if (opp != null) ...[
                PlayerBar(me: me ?? const PlayerInfo(name: 'Vous', isMe: true), opp: opp!),
                const SizedBox(height: 16),
              ],
              Text(_status(), textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 24),
              Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 420),
                  child: ctrl.game.buildBoard(
                    context,
                    canPlay: ctrl.canHumanPlay,
                    onMove: ctrl.humanMove,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              if (ctrl.game.isOver && widget.lan == null)
                FilledButton.icon(
                  icon: const Icon(Icons.replay),
                  label: const Text('Rejouer'),
                  onPressed: () {
                    final old = ctrl;
                    setState(() => ctrl = _make());
                    old.dispose();
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── LAN : hôte ─────────────────────────

class LanHostScreen extends StatefulWidget {
  final GameDef def;
  const LanHostScreen({super.key, required this.def});

  @override
  State<LanHostScreen> createState() => _LanHostScreenState();
}

class _LanHostScreenState extends State<LanHostScreen> {
  final LanHost host = LanHost();
  List<String> ips = [];
  String? error;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    final found = await LanHost.localIps();
    if (mounted) setState(() => ips = found);
    try {
      final conn = await host.waitForPlayer();
      if (!mounted) {
        conn.close();
        return;
      }
      final seed = Random().nextInt(1 << 30);
      conn.send({'type': 'start', 'game': widget.def.id, 'seed': seed});
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => GameScreen(
          def: widget.def,
          seats: const [Seat.human, Seat.remote],
          names: const ['Vous', 'Adversaire'],
          lan: conn,
          seed: seed,
        ),
      ));
    } catch (e) {
      if (mounted) setState(() => error = 'Erreur : $e');
    }
  }

  @override
  void dispose() {
    host.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text('Créer : ${widget.def.title}')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Center(child: CircularProgressIndicator()),
            const SizedBox(height: 24),
            Text('En attente d\'un adversaire…',
                textAlign: TextAlign.center, style: text.titleMedium),
            const SizedBox(height: 16),
            const Text(
              'Sur l\'autre téléphone (même Wi-Fi), choisir '
              '« Rejoindre une partie » et saisir cette adresse :',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            for (final ip in ips)
              SelectableText(ip,
                  textAlign: TextAlign.center, style: text.titleLarge),
            if (ips.isEmpty)
              const Text('Aucune adresse Wi-Fi trouvée. Es-tu connecté ?',
                  textAlign: TextAlign.center),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: Text(error!,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ),
          ],
        ),
      ),
    );
  }
}

// ───────────────────────── LAN : invité ─────────────────────────

class LanJoinScreen extends StatefulWidget {
  const LanJoinScreen({super.key});

  @override
  State<LanJoinScreen> createState() => _LanJoinScreenState();
}

class _LanJoinScreenState extends State<LanJoinScreen> {
  final TextEditingController ipCtrl = TextEditingController();
  bool busy = false;
  String? error;

  @override
  void dispose() {
    ipCtrl.dispose();
    super.dispose();
  }

  Future<void> _join() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final conn = await LanClient.connect(ipCtrl.text.trim());
      conn.onMessage = (msg) {
        if (msg['type'] != 'start') return;
        conn.onMessage = null; // les coups suivants restent en attente
        final def = gameById(msg['game'] as String);
        if (def == null || !mounted) {
          conn.close();
          return;
        }
        Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (_) => GameScreen(
            def: def,
            seats: const [Seat.remote, Seat.human],
            names: const ['Adversaire', 'Vous'],
            lan: conn,
            seed: msg['seed'] as int?,
          ),
        ));
      };
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = 'Connexion impossible. Vérifie l\'adresse et le Wi-Fi.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rejoindre une partie')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: ipCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Adresse de l\'hôte (ex : 192.168.1.12)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: busy ? null : _join,
              child: Text(busy ? 'Connexion…' : 'Rejoindre'),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: Text(error!,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ),
          ],
        ),
      ),
    );
  }
}


// ───────────────────────── En ligne (Supabase) ─────────────────────────

class OnlineScreen extends StatefulWidget {
  final GameDef def;
  const OnlineScreen({super.key, required this.def});

  @override
  State<OnlineScreen> createState() => _OnlineScreenState();
}

class _OnlineScreenState extends State<OnlineScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final username = TextEditingController();
  final code = TextEditingController();
  bool signup = false, busy = false;
  String? error;

  @override
  void initState() {
    super.initState();
    if (OnlineService.user != null) _checkTerms();
  }

  /// Première connexion (ou nouvelle version du message) : le joueur doit lire et accepter.
  Future<void> _checkTerms() async {
    var ok = false;
    try {
      ok = await Social.termsAccepted();
    } catch (_) {}
    if (ok || !mounted) return;
    final accepted = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const TermsScreen()));
    if (accepted != true) await OnlineService.signOut();
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    username.dispose();
    code.dispose();
    super.dispose();
  }

  String _authMessage(AuthException e) {
    final m = e.message.toLowerCase();
    if (m.contains('already_registered') || m.contains('already registered')) {
      return 'Un compte existe déjà avec cet e-mail. Connecte-toi avec ton mot de passe, ou utilise une autre adresse.';
    }
    if (m.contains('invalid login') || m.contains('invalid_credentials')) return 'E-mail ou mot de passe incorrect.';
    if (m.contains('password')) return 'Mot de passe trop court ou trop faible (6 caractères minimum).';
    if (m.contains('valid') && m.contains('email')) return 'Adresse e-mail invalide.';
    if (m.contains('confirm')) return 'Confirme ton adresse e-mail (message reçu dans ta boîte mail), puis connecte-toi.';
    if (m.contains('rate') || m.contains('too many')) return 'Trop d’essais. Attends une minute puis réessaie.';
    return 'Échec : ${e.message}';
  }

  Future<void> _auth() async {
    final mail = email.text.trim(), pseudo = username.text.trim();
    if (!mail.contains('@')) {
      setState(() => error = 'Adresse e-mail invalide.');
      return;
    }
    if (password.text.length < 6) {
      setState(() => error = 'Le mot de passe doit faire au moins 6 caractères.');
      return;
    }
    if (signup && (pseudo.length < 3 || pseudo.length > 30)) {
      setState(() => error = 'Le pseudo doit faire entre 3 et 30 caractères.');
      return;
    }
    setState(() {
      busy = true;
      error = null;
    });
    try {
      if (signup) {
        await OnlineService.signUp(mail, password.text, pseudo);
      } else {
        await OnlineService.signIn(mail, password.text);
      }
    } on AuthException catch (e) {
      error = _authMessage(e);
      if (e.message.toLowerCase().contains('already_registered')) signup = false;
    } catch (_) {
      error = 'Pas de connexion à internet, ou service indisponible. Réessaie.';
    }
    if (OnlineService.user != null) await _checkTerms();
    if (mounted) setState(() => busy = false);
  }

  Future<void> _join() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final conn = await LanClient.connect(ipCtrl.text.trim());
      conn.onMessage = (msg) {
        if (msg['type'] != 'start') return;
        conn.onMessage = null; // les coups suivants restent en attente
        final def = gameById(msg['game'] as String);
        if (def == null || !mounted) {
          conn.close();
          return;
        }
        Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (_) => GameScreen(
            def: def,
            seats: const [Seat.remote, Seat.human],
            names: const ['Adversaire', 'Vous'],
            lan: conn,
          ),
        ));
      };
    } catch (_) {
      if (mounted) {
        setState(() {
          busy = false;
          error = 'Connexion impossible. Vérifie l\'adresse et le Wi-Fi.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Rejoindre une partie')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: ipCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Adresse de l\'hôte (ex : 192.168.1.12)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: busy ? null : _join,
              child: Text(busy ? 'Connexion…' : 'Rejoindre'),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: Text(error!,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ),
          ],
        ),
      ),
    );
  }
}


// ───────────────────────── En ligne (Supabase) ─────────────────────────

class OnlineScreen extends StatefulWidget {
  final GameDef def;
  const OnlineScreen({super.key, required this.def});

  @override
  State<OnlineScreen> createState() => _OnlineScreenState();
}

class _OnlineScreenState extends State<OnlineScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final username = TextEditingController();
  final code = TextEditingController();
  bool signup = false, busy = false;
  String? error;

  @override
  void initState() {
    super.initState();
    if (OnlineService.user != null) _checkTerms();
  }

  /// Première connexion (ou nouvelle version du message) : le joueur doit lire et accepter.
  Future<void> _checkTerms() async {
    var ok = false;
    try {
      ok = await Social.termsAccepted();
    } catch (_) {}
    if (ok || !mounted) return;
    final accepted = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const TermsScreen()));
    if (accepted != true) await OnlineService.signOut();
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    username.dispose();
    code.dispose();
    super.dispose();
  }

  Future<void> _auth() async {
    setState(() { busy = true; error = null; });
    try {
      if (signup) {
        await OnlineService.signUp(email.text.trim(), password.text, username.text.trim());
      } else {
        await OnlineService.signIn(email.text.trim(), password.text);
      }
    } catch (e) {
      error = 'Connexion impossible : vérifie tes informations.';
    }
    if (OnlineService.user != null) await _checkTerms();
    if (mounted) setState(() => busy = false);
  }

  Future<void> _join() async {
    setState(() { busy = true; error = null; });
    try {
      final room = await OnlineService.joinRoom(code.text);
      final def = room == null ? null : gameById(room['game'] as String);
      if (def == null) {
        error = 'Salle introuvable ou déjà complète.';
      } else if (mounted) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (_) => GameScreen(
            def: def,
            seats: const [Seat.remote, Seat.human],
            names: const ['Adversaire', 'Vous'],
            lan: OnlineLink(room!['id'] as String),
          ),
        ));
        return;
      }
    } catch (e) {
      error = 'Impossible de rejoindre la salle.';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final user = OnlineService.user;
    final err = error == null
        ? const SizedBox.shrink()
        : Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          );
    return Scaffold(
      appBar: AppBar(title: Text('En ligne : ${widget.def.title}')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: user == null
            ? [
                if (signup)
                  TextField(controller: username, decoration: const InputDecoration(labelText: 'Pseudo (3 à 30 caractères)', border: OutlineInputBorder())),
                if (signup) const SizedBox(height: 12),
                TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'E-mail', border: OutlineInputBorder())),
                const SizedBox(height: 12),
                TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Mot de passe', border: OutlineInputBorder())),
                const SizedBox(height: 16),
                FilledButton(onPressed: busy ? null : _auth, child: Text(signup ? 'Créer mon compte' : 'Se connecter')),
                TextButton(onPressed: () => setState(() => signup = !signup), child: Text(signup ? 'J\'ai déjà un compte' : 'Pas de compte ? S\'inscrire')),
                err,
              ]
            : [
                Text('Connecté : ${user.email}', style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 20),
                FilledButton.icon(
                  icon: const Icon(Icons.bolt),
                  label: const Text('Partie rapide'),
                  onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => QuickMatchScreen(def: widget.def))),
                ),
                const SizedBox(height: 12),
                FilledButton.tonalIcon(
                  icon: const Icon(Icons.add),
                  label: const Text('Créer une salle'),
                  onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => OnlineHostScreen(def: widget.def))),
                ),
                const SizedBox(height: 24),
                TextField(controller: code, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Code de la salle (6 caractères)', border: OutlineInputBorder())),
                const SizedBox(height: 12),
                FilledButton.tonal(onPressed: busy ? null : _join, child: const Text('Rejoindre')),
                err,
                TextButton(onPressed: () async { await OnlineService.signOut(); if (mounted) setState(() {}); }, child: const Text('Se déconnecter')),
              ],
      ),
    );
  }
}

class OnlineHostScreen extends StatefulWidget {
  final GameDef def;
  const OnlineHostScreen({super.key, required this.def});

  @override
  State<OnlineHostScreen> createState() => _OnlineHostScreenState();
}

class _OnlineHostScreenState extends State<OnlineHostScreen> {
  String? code, roomId, error;
  OnlineLobby? lobby;
  bool started = false;

  @override
  void initState() {
    super.initState();
    _create();
  }

  Future<void> _create() async {
    try {
      final room = await OnlineService.createRoom(widget.def.id);
      roomId = room['id'] as String;
      if (mounted) setState(() => code = room['code'] as String);
      lobby = OnlineLobby(roomId!, _start);
    } catch (e) {
      if (mounted) setState(() => error = 'Impossible de créer la salle.');
    }
  }

  void _start() {
    if (!mounted || started) return;
    started = true;
    lobby?.close();
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => GameScreen(
        def: widget.def,
        seats: const [Seat.human, Seat.remote],
        names: const ['Vous', 'Adversaire'],
        lan: OnlineLink(roomId!),
      ),
    ));
  }

  @override
  void dispose() {
    lobby?.close();
    if (!started && roomId != null) OnlineService.deleteRoom(roomId!);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text('Salle : ${widget.def.title}')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (error != null) Text(error!, textAlign: TextAlign.center) else ...[
              const Center(child: CircularProgressIndicator()),
              const SizedBox(height: 24),
              Text('Donne ce code à ton adversaire :', textAlign: TextAlign.center, style: t.titleMedium),
              const SizedBox(height: 12),
              SelectableText(code ?? '…', textAlign: TextAlign.center, style: t.headlineSmall),
            ],
          ],
        ),
      ),
    );
  }
}
