import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../core/board_game.dart';
import '../core/chat.dart';
import '../core/game_controller.dart';
import '../core/online.dart';
import '../core/people.dart';
import '../core/social_service.dart';
import '../core/terms.dart';
import '../core/voice.dart';
import '../games/registry.dart';
import 'screens.dart';

// ───────────────────────── Avatar, carte joueur, barre « moi VS adversaire » ─────────────────────────

class PlayerAvatar extends StatelessWidget {
  final PlayerInfo p;
  final double radius;
  const PlayerAvatar({super.key, required this.p, this.radius = 22});

  @override
  Widget build(BuildContext context) {
    if (p.avatarUrl != null) {
      return CircleAvatar(radius: radius, backgroundImage: NetworkImage(p.avatarUrl!));
    }
    return CircleAvatar(
      radius: radius,
      backgroundColor: p.color ?? Theme.of(context).colorScheme.primaryContainer,
      child: Text(
        p.emoji ?? (p.name.isEmpty ? '?' : p.name[0].toUpperCase()),
        style: TextStyle(fontSize: radius * .9),
      ),
    );
  }
}

class PlayerCard extends StatelessWidget {
  final PlayerInfo p;
  const PlayerCard({super.key, required this.p});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerProfileScreen(p: p))),
      child: Row(
      children: [
        PlayerAvatar(p: p),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Flexible(child: Text(p.name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600))),
              ]),
              Text('${flagOf(p.country)} ${countryName(p.country)}', overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ],
    ),
    );
  }
}

class PlayerBar extends StatelessWidget {
  final PlayerInfo me, opp;
  const PlayerBar({super.key, required this.me, required this.opp});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: PlayerCard(p: me)),
      const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('VS', style: TextStyle(fontWeight: FontWeight.bold))),
      Expanded(child: PlayerCard(p: opp)),
    ]);
  }
}

// ───────────────────────── Joueurs IA ─────────────────────────

class AiPlayersScreen extends StatefulWidget {
  const AiPlayersScreen({super.key});

  @override
  State<AiPlayersScreen> createState() => _AiPlayersScreenState();
}

class _AiPlayersScreenState extends State<AiPlayersScreen> {
  late final Future<List<PlayerInfo>> future = Social.aiPlayers();

  Future<void> _pick(PlayerInfo ai) async {
    final me = await Social.myInfo();
    if (!mounted) return;
    final def = await showModalBottomSheet<GameDef>(
      context: context,
      builder: (sheet) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            for (final g in allGames)
              ListTile(leading: Icon(g.icon), title: Text(g.title), onTap: () => Navigator.of(sheet).pop(g)),
          ],
        ),
      ),
    );
    if (def == null || !mounted) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => GameScreen(
        def: def,
        seats: const [Seat.human, Seat.bot],
        names: ['Vous', ai.name],
        me: me ?? const PlayerInfo(name: 'Vous', isMe: true),
        opp: ai,
        botLevel: ai.level,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Joueurs IA')),
      body: FutureBuilder<List<PlayerInfo>>(
        future: future,
        builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('Impossible de charger les joueurs IA.'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          return ListView.separated(
            itemCount: snap.data!.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final p = snap.data![i];
              return ListTile(
                leading: PlayerAvatar(p: p),
                title: Text(p.name),
                subtitle: Text('${flagOf(p.country)} ${countryName(p.country)} · Joueur virtuel · ${levelNames[p.level]}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _pick(p),
              );
            },
          );
        },
      ),
    );
  }
}

// ───────────────────────── Profil : pseudo, nationalité, photo ─────────────────────────

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final name = TextEditingController();
  PlayerInfo? me;
  String? country, msg;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (OnlineService.user == null) {
      setState(() => msg = 'Connecte-toi d’abord : ouvre un jeu, puis « En ligne ».');
      return;
    }
    try {
      final m = await Social.myInfo();
      if (!mounted || m == null) return;
      setState(() {
        me = m;
        name.text = m.name;
        country = m.country;
      });
    } catch (_) {
      if (mounted) setState(() => msg = 'Impossible de charger ton profil.');
    }
  }

  Future<void> _photo() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 512, maxHeight: 512, imageQuality: 85);
      if (x == null) return;
      setState(() => busy = true);
      final ext = x.name.contains('.') ? x.name.split('.').last.toLowerCase() : 'jpg';
      final url = await Social.uploadAvatar(await x.readAsBytes(), ext);
      if (mounted) {
        setState(() {
          me = PlayerInfo(name: me!.name, country: country, avatarUrl: url, isMe: true);
          msg = 'Photo mise à jour.';
        });
      }
    } catch (_) {
      if (mounted) setState(() => msg = 'Photo impossible (JPEG, PNG ou WebP, 2 Mo maximum).');
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _save() async {
    setState(() => busy = true);
    try {
      await Social.updateProfile(name.text.trim(), country);
      msg = 'Profil enregistré.';
    } catch (_) {
      msg = 'Enregistrement impossible (pseudo de 3 à 30 caractères).';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mon profil')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          if (me != null) ...[
            Center(
              child: GestureDetector(
                onTap: busy ? null : _photo,
                child: Stack(alignment: Alignment.bottomRight, children: [
                  PlayerAvatar(p: me!, radius: 52),
                  const CircleAvatar(radius: 16, child: Icon(Icons.edit, size: 16)),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            const Center(child: Text('Touche la photo pour la changer')),
            const SizedBox(height: 24),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Pseudo', border: OutlineInputBorder())),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: country,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Nationalité', border: OutlineInputBorder()),
              items: [
                for (final e in countries.entries) DropdownMenuItem(value: e.key, child: Text('${flagOf(e.key)}  ${e.value}')),
              ],
              onChanged: (v) => setState(() => country = v),
            ),
            const SizedBox(height: 20),
            FilledButton(onPressed: busy ? null : _save, child: const Text('Enregistrer')),
          ],
          if (msg != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(msg!, textAlign: TextAlign.center)),
        ],
      ),
    );
  }
}

// ───────────────────────── Chat et appel vocal en partie ─────────────────────────

class ChatSheet extends StatefulWidget {
  final ChatChannel chat;
  const ChatSheet({super.key, required this.chat});

  @override
  State<ChatSheet> createState() => _ChatSheetState();
}

class _ChatSheetState extends State<ChatSheet> {
  final ctl = TextEditingController();

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  void _send() {
    final t = ctl.text.trim();
    if (t.isEmpty) return;
    widget.chat.send(t);
    ctl.clear();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SizedBox(
        height: 380,
        child: Column(children: [
          Expanded(
            child: ValueListenableBuilder<List<ChatMsg>>(
              valueListenable: widget.chat.messages,
              builder: (_, msgs, __) => ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  for (final m in msgs)
                    Align(
                      alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: m.mine ? cs.primaryContainer : cs.secondaryContainer,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(m.text),
                      ),
                    ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: ctl,
                  onSubmitted: (_) => _send(),
                  decoration: const InputDecoration(hintText: 'Écrire un message…', border: OutlineInputBorder()),
                ),
              ),
              IconButton(onPressed: _send, icon: const Icon(Icons.send)),
            ]),
          ),
        ]),
      ),
    );
  }
}

class CallButton extends StatelessWidget {
  final VoiceCall call;
  const CallButton({super.key, required this.call});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: call,
      builder: (ctx, _) {
        Future<void> guard(Future<void> Function() f) async {
          try {
            await f();
          } catch (_) {
            if (ctx.mounted) {
              ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(content: Text('Micro indisponible ou appel impossible.')));
            }
          }
        }

        switch (call.state) {
          case CallState.idle:
            return IconButton(tooltip: 'Appel vocal', icon: const Icon(Icons.call), onPressed: () => guard(call.call));
          case CallState.calling:
            return IconButton(tooltip: 'Annuler l’appel', icon: const Icon(Icons.call_end, color: Colors.red), onPressed: call.hangup);
          case CallState.incoming:
            return Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(tooltip: 'Répondre', icon: const Icon(Icons.call, color: Colors.green), onPressed: () => guard(call.accept)),
              IconButton(tooltip: 'Refuser', icon: const Icon(Icons.call_end, color: Colors.red), onPressed: call.hangup),
            ]);
          case CallState.connected:
            return Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(tooltip: 'Micro', icon: Icon(call.muted ? Icons.mic_off : Icons.mic), onPressed: call.toggleMute),
              IconButton(tooltip: 'Raccrocher', icon: const Icon(Icons.call_end, color: Colors.red), onPressed: call.hangup),
            ]);
        }
      },
    );
  }
}

// ───────────────────────── Profil d'un joueur (on y voit s'il s'agit d'un joueur virtuel) ─────────────────────────

class PlayerProfileScreen extends StatelessWidget {
  final PlayerInfo p;
  const PlayerProfileScreen({super.key, required this.p});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(p.name)),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Center(child: PlayerAvatar(p: p, radius: 52)),
          const SizedBox(height: 16),
          Center(child: Text(p.name, style: Theme.of(context).textTheme.titleMedium)),
          Center(child: Text('${flagOf(p.country)} ${countryName(p.country)}')),
          const SizedBox(height: 24),
          ListTile(
            leading: Icon(p.isBot ? Icons.smart_toy_outlined : Icons.person_outline),
            title: Text(p.isBot ? 'Joueur virtuel (IA)' : 'Joueur'),
            subtitle: Text(p.isBot
                ? 'Ce joueur est contrôlé par une IA. Niveau : ${levelNames[p.level]}.'
                : 'Joueur de l’application.'),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── Partie rapide : un joueur en attente, sinon un joueur virtuel après 10 s ─────────────────────────

PlayerInfo _pickAi(List<PlayerInfo> all) {
  // Les niveaux facile et moyen sont plus fréquents : l'IA ne gagne pas à chaque fois.
  const w = {1: 4.0, 2: 4.5, 3: 1.5};
  final total = all.fold<double>(0, (a, p) => a + w[p.level]!);
  var x = Random().nextDouble() * total;
  for (final p in all) {
    x -= w[p.level]!;
    if (x <= 0) return p;
  }
  return all.last;
}

class QuickMatchScreen extends StatefulWidget {
  final GameDef def;
  const QuickMatchScreen({super.key, required this.def});

  @override
  State<QuickMatchScreen> createState() => _QuickMatchScreenState();
}

class _QuickMatchScreenState extends State<QuickMatchScreen> {
  static const waitSeconds = 10;
  int left = waitSeconds;
  Timer? tick;
  OnlineLobby? lobby;
  String? roomId, error;
  PlayerInfo? ai;
  bool started = false;

  @override
  void initState() {
    super.initState();
    _search();
  }

  Future<void> _search() async {
    tick?.cancel();
    setState(() {
      ai = null;
      error = null;
      left = waitSeconds;
    });
    try {
      // 1) Un joueur est déjà en attente : on le rejoint tout de suite.
      final room = await OnlineService.joinWaiting(widget.def.id);
      if (room != null) {
        _startOnline(room['id'] as String, host: false);
        return;
      }
      // 2) Sinon on attend ici pendant 10 secondes.
      final mine = await OnlineService.createRoom(widget.def.id, quick: true);
      roomId = mine['id'] as String;
      lobby = OnlineLobby(roomId!, () => _startOnline(roomId!, host: true));
      tick = Timer.periodic(const Duration(seconds: 1), (t) async {
        if (!mounted || started) {
          t.cancel();
          return;
        }
        setState(() => left--);
        if (left > 0 && left % 2 == 0) {
          final other = await OnlineService.joinWaiting(widget.def.id, below: roomId);
          if (other != null && !started) {
            t.cancel();
            final removed = await OnlineService.removeWaiting(roomId!);
            if (!removed) await OnlineService.finishRoom(roomId!);
            roomId = null;
            _startOnline(other['id'] as String, host: false);
            return;
          }
        }
        if (left <= 0) {
          t.cancel();
          await _noHuman();
        }
      });
    } catch (_) {
      if (mounted) setState(() => error = 'Recherche impossible. Vérifie ta connexion.');
    }
  }

  Future<void> _noHuman() async {
    lobby?.close();
    lobby = null;
    // Personne n'est venu : on retire notre salle. Si quelqu'un vient de la rejoindre, on joue avec lui.
    if (roomId != null && !await OnlineService.removeWaiting(roomId!)) {
      _startOnline(roomId!, host: true);
      return;
    }
    roomId = null;
    try {
      final all = await Social.aiPlayers();
      ai = _pickAi(all);
      await _playAi();
    } catch (_) {
      if (mounted) setState(() => error = 'Aucun adversaire disponible pour le moment.');
    }
  }

  void _startOnline(String id, {required bool host}) {
    if (!mounted || started) return;
    started = true;
    tick?.cancel();
    lobby?.close();
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => GameScreen(
        def: widget.def,
        seats: host ? const [Seat.human, Seat.remote] : const [Seat.remote, Seat.human],
        names: host ? const ['Vous', 'Adversaire'] : const ['Adversaire', 'Vous'],
        lan: OnlineLink(id),
      ),
    ));
  }

  Future<void> _playAi() async {
    final me = await Social.myInfo();
    if (!mounted || ai == null) return;
    started = true;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => GameScreen(
        def: widget.def,
        seats: const [Seat.human, Seat.bot],
        names: ['Vous', ai!.name],
        me: me ?? const PlayerInfo(name: 'Vous', isMe: true),
        opp: ai,
        botLevel: ai!.level,
      ),
    ));
  }

  @override
  void dispose() {
    tick?.cancel();
    lobby?.close();
    if (!started && roomId != null) OnlineService.deleteRoom(roomId!);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    Widget body;
    if (error != null) {
      body = Column(mainAxisSize: MainAxisSize.min, children: [
        Text(error!, textAlign: TextAlign.center),
        const SizedBox(height: 16),
        FilledButton(onPressed: _search, child: const Text('Réessayer')),
      ]);
    } else {
      body = Column(mainAxisSize: MainAxisSize.min, children: [
        const CircularProgressIndicator(),
        const SizedBox(height: 20),
        Text('Recherche d’un adversaire…', style: t.titleMedium),
        const SizedBox(height: 8),
        Text('${left > 0 ? left : 0} s'),
      ]);
    }
    return Scaffold(
      appBar: AppBar(title: Text('Partie rapide : ${widget.def.title}')),
      body: Center(child: Padding(padding: const EdgeInsets.all(24), child: body)),
    );
  }
}

// ───────────────────────── Message d'explication (première connexion) ─────────────────────────

class TermsScreen extends StatefulWidget {
  const TermsScreen({super.key});

  @override
  State<TermsScreen> createState() => _TermsScreenState();
}

class _TermsScreenState extends State<TermsScreen> {
  final scroll = ScrollController();
  bool atEnd = false, busy = false;

  @override
  void initState() {
    super.initState();
    scroll.addListener(_check);
    WidgetsBinding.instance.addPostFrameCallback((_) => _check());
  }

  void _check() {
    if (!scroll.hasClients) return;
    final end = scroll.position.pixels >= scroll.position.maxScrollExtent - 24;
    if (end != atEnd) setState(() => atEnd = end);
  }

  @override
  void dispose() {
    scroll.dispose();
    super.dispose();
  }

  Future<void> _accept() async {
    setState(() => busy = true);
    try {
      await Social.acceptTerms();
      if (mounted) Navigator.of(context).pop(true);
    } catch (_) {
      if (mounted) {
        setState(() => busy = false);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enregistrement impossible, réessaie.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Comment ça marche'), automaticallyImplyLeading: false),
      body: Column(children: [
        Expanded(
          child: ListView(
            controller: scroll,
            padding: const EdgeInsets.all(20),
            children: [
              for (final s in termsSections) ...[
                Text(s[0], style: t.titleMedium),
                const SizedBox(height: 6),
                Text(s[1], style: t.bodyMedium),
                const SizedBox(height: 18),
              ],
            ],
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (!atEnd) Text('Fais défiler jusqu’en bas pour continuer.', style: t.bodySmall),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: OutlinedButton(onPressed: busy ? null : () => Navigator.of(context).pop(false), child: const Text('Je refuse'))),
                const SizedBox(width: 12),
                Expanded(child: FilledButton(onPressed: (atEnd && !busy) ? _accept : null, child: const Text('J’ai lu et j’accepte'))),
              ]),
            ]),
          ),
        ),
      ]),
    );
  }
}
