import 'dart:async';
import 'package:flutter/material.dart';
import 'screens.dart';

/// Écran de démarrage : nom de l'application et signature. Se ferme tout seul (ou d'un toucher).
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
  Timer? _t;
  bool _gone = false;

  @override
  void initState() {
    super.initState();
    _t = Timer(const Duration(milliseconds: 2800), _next);
  }

  void _next() {
    if (_gone || !mounted) return;
    _gone = true;
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (_, __, ___) => const HomeScreen(),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
    ));
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: cs.primary,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _next,
        child: SafeArea(
          child: FadeTransition(
            opacity: CurvedAnimation(parent: _c, curve: Curves.easeOut),
            child: SizedBox(
              width: double.infinity,
              child: Column(children: [
                const Spacer(flex: 3),
                Container(
                  width: 96,
                  height: 96,
                  decoration: BoxDecoration(color: cs.onPrimary.withOpacity(.15), borderRadius: BorderRadius.circular(28)),
                  child: Icon(Icons.casino, size: 52, color: cs.onPrimary),
                ),
                const SizedBox(height: 22),
                Text('Rotegan', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700, letterSpacing: 1, color: cs.onPrimary)),
                const SizedBox(height: 6),
                Text('Jeux de société, en ligne et hors ligne', style: TextStyle(fontSize: 13, color: cs.onPrimary.withOpacity(.8))),
                const Spacer(flex: 4),
                Text('Développé par', style: TextStyle(fontSize: 11, color: cs.onPrimary.withOpacity(.7))),
                const SizedBox(height: 2),
                Text('E. Anselme Dossou-Yovo', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: cs.onPrimary)),
                const SizedBox(height: 28),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
