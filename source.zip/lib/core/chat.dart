import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'online.dart';
import 'people.dart';

class ChatMsg {
  final bool mine;
  final String text;
  const ChatMsg(this.mine, this.text);
}

abstract class ChatChannel {
  final ValueNotifier<List<ChatMsg>> messages = ValueNotifier([]);
  void send(String text);
  void dispose() {}
}

/// Chat avec un joueur IA : les réponses sont des phrases préécrites (pas de modèle de langage).
class BotChat extends ChatChannel {
  final PlayerInfo bot;
  final Random _rnd = Random();
  bool _dead = false;

  static const _replies = [
    '😄 Bien joué !',
    'Hmm, tu joues bien…',
    'Je réfléchis…',
    'On continue ? 😉',
    'Pas mal du tout !',
    '👍',
  ];

  BotChat(this.bot) {
    Future.delayed(const Duration(milliseconds: 1200), () => say(bot.greeting ?? 'Salut !'));
  }

  void say(String text) {
    if (_dead) return;
    messages.value = [...messages.value, ChatMsg(false, text)];
  }

  @override
  void send(String text) {
    messages.value = [...messages.value, ChatMsg(true, text)];
    Future.delayed(const Duration(milliseconds: 1000), () => say(_replies[_rnd.nextInt(_replies.length)]));
  }

  @override
  void dispose() => _dead = true;
}

/// Chat entre deux joueurs humains d'une salle (table room_messages, temps réel).
class OnlineChat extends ChatChannel {
  final String roomId;
  late final RealtimeChannel _ch;
  final String _me = OnlineService.user!.id;

  OnlineChat(this.roomId) {
    _load();
    _ch = sb
        .channel('chat_$roomId')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'room_messages',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'room_id', value: roomId),
          callback: (p) {
            final r = p.newRecord;
            if (r['sender'] != _me) messages.value = [...messages.value, ChatMsg(false, r['body'] as String)];
          },
        )
        .subscribe();
  }

  Future<void> _load() async {
    try {
      final rows = await sb.from('room_messages').select('sender, body').eq('room_id', roomId).order('id');
      messages.value = [for (final r in rows) ChatMsg(r['sender'] == _me, r['body'] as String)];
    } catch (_) {}
  }

  @override
  void send(String text) {
    final t = text.length > 500 ? text.substring(0, 500) : text;
    messages.value = [...messages.value, ChatMsg(true, t)];
    sb.from('room_messages').insert({'room_id': roomId, 'body': t}).then((_) {}, onError: (_) {});
  }

  @override
  void dispose() => sb.removeChannel(_ch);
}

/// Chat avec un joueur virtuel propulsé par un modèle de langage. La clé API reste sur le serveur
/// (fonction Supabase « bot-chat ») : l'application n'en contient aucune.
/// Le joueur connaît son identité (nom, pays), l'état de la partie, et attend 25 s avant de répondre.
class LlmBotChat extends ChatChannel {
  final PlayerInfo bot;
  final String playerName;
  final Map<String, dynamic> Function() gameContext;
  final Random _rnd = Random();
  bool _busy = false, _dead = false;
  int _unanswered = 0;

  static const replyDelay = Duration(seconds: 25);
  static const eventDelay = Duration(seconds: 4);
  static const _fallback = ['😄 Bien joué !', 'Hmm, pas mal…', 'Je réfléchis…', 'On continue ? 😉', '👍'];

  LlmBotChat({required this.bot, required this.playerName, required this.gameContext}) {
    Future.delayed(const Duration(seconds: 3), () => _say(bot.greeting ?? 'Salut !'));
  }

  void _say(String text) {
    if (_dead) return;
    messages.value = [...messages.value, ChatMsg(false, text.length > 160 ? text.substring(0, 160) : text)];
  }

  @override
  void send(String text) {
    messages.value = [...messages.value, ChatMsg(true, text)];
    _unanswered++;
    _reply(null);
  }

  /// Petite réaction à la fin de la partie.
  void reactToGameOver() => _reply('gameover');

  Future<void> _reply(String? event) async {
    if (_busy || _dead || (_unanswered == 0 && event == null)) return;
    _busy = true;
    _unanswered = 0;
    final history = [
      for (final m in messages.value.length > 12 ? messages.value.sublist(messages.value.length - 12) : messages.value)
        {'mine': m.mine, 'text': m.text}
    ];
    final results = await Future.wait<String?>([
      Future<String?>.delayed(event == null ? replyDelay : eventDelay),
      _ask(history, event),
    ]);
    final reply = results[1] ?? (event == null ? _fallback[_rnd.nextInt(_fallback.length)] : null);
    if (reply != null) _say(reply);
    _busy = false;
    if (_unanswered > 0) _reply(null);
  }

  Future<String?> _ask(List<Map<String, Object>> history, String? event) async {
    try {
      final res = await sb.functions.invoke('bot-chat', body: {
        'bot_id': bot.botId,
        'event': event,
        'player': {'name': playerName},
        'game': gameContext(),
        'history': history,
      });
      final data = res.data;
      if (data is Map && data['reply'] is String) return data['reply'] as String;
    } catch (_) {}
    return null;
  }

  @override
  void dispose() => _dead = true;
}
