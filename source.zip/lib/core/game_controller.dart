import 'dart:math';
import 'package:flutter/foundation.dart';
import 'board_game.dart';
import 'lan.dart';

/// Qui contrôle chaque siège : un humain sur ce téléphone,
/// un bot, ou un adversaire distant (LAN / en ligne).
enum Seat { human, bot, remote }

class GameController extends ChangeNotifier {
  final BoardGame game;
  final List<Seat> seats;
  final GameLink? lan;
  final int botLevel; // 1 facile, 2 moyen, 3 difficile
  final Random _rnd = Random();
  bool _disposed = false;
  bool disconnected = false;
  bool scoreSaved = false;
  int moveCount = 0;

  GameController(this.game, this.seats, {this.lan, this.botLevel = 3}) {
    lan?.onMessage = _onRemote;
    _scheduleBot();
  }

  bool get canHumanPlay =>
      !game.isOver &&
      !disconnected &&
      seats[game.currentPlayer] == Seat.human;

  void humanMove(Move move) {
    if (!canHumanPlay || !game.isLegal(move)) return;
    game.play(move);
    moveCount++;
    lan?.send({'type': 'move', 'move': move});
    notifyListeners();
    _scheduleBot();
  }

  void _scheduleBot() {
    if (game.isOver || seats[game.currentPlayer] != Seat.bot) return;
    Future.delayed(const Duration(milliseconds: 600), () {
      if (_disposed || game.isOver || seats[game.currentPlayer] != Seat.bot) {
        return;
      }
      final mv = game.legalMoves();
      final chance = const [0.0, 0.6, 0.25, 0.0][botLevel];
      game.play(_rnd.nextDouble() < chance ? mv[_rnd.nextInt(mv.length)] : game.botMove(_rnd));
      moveCount++;
      notifyListeners();
      _scheduleBot();
    });
  }

  void _onRemote(Map<String, dynamic> msg) {
    if (_disposed) return;
    if (msg['type'] == 'closed') {
      disconnected = true;
      notifyListeners();
      return;
    }
    if (msg['type'] != 'move' ||
        game.isOver ||
        seats[game.currentPlayer] != Seat.remote) {
      return;
    }
    final move = Map<String, dynamic>.from(msg['move'] as Map);
    if (!game.isLegal(move)) return; // on ne fait pas confiance au réseau
    game.play(move);
    moveCount++;
    notifyListeners();
    _scheduleBot();
  }

  @override
  void dispose() {
    _disposed = true;
    lan?.close();
    super.dispose();
  }
}
