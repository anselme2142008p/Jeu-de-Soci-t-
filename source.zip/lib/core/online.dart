import 'package:supabase_flutter/supabase_flutter.dart';
import 'lan.dart';

// Projet Supabase « Jeux ». La clé « publishable » est faite pour être dans
// l'application : la sécurité repose sur les règles RLS de la base.
const supabaseUrl = 'https://qmskhzfcrvisasvrymwq.supabase.co';
const supabaseKey = 'sb_publishable_MytrqXoS1lkD-jIZqoP7Kg_A3yRff5G';

SupabaseClient get sb => Supabase.instance.client;

/// Compte, salles à 2 joueurs (table `rooms`) et scores (table `scores`).
class OnlineService {
  static User? get user => sb.auth.currentUser;

  // L'e-mail est confirmé automatiquement et le profil est créé par la base
  // à partir du pseudo envoyé dans `data`.
  static Future<void> signUp(String email, String password, String username) =>
      sb.auth.signUp(email: email, password: password, data: {'username': username});

  static Future<void> signIn(String email, String password) =>
      sb.auth.signInWithPassword(email: email, password: password);

  static Future<void> signOut() => sb.auth.signOut();

  /// Crée une salle en attente. Le code à 6 caractères est généré par la base.
  static Future<Map<String, dynamic>> createRoom(String gameId, {bool quick = false}) => sb
      .from('rooms')
      .insert({'game': gameId, 'state': {'moves': [], if (quick) 'quick': true}})
      .select()
      .single();

  /// Partie rapide : rejoint un joueur déjà en attente (salle rapide créée il y a moins de 20 s).
  /// `below` : on ne rejoint que les salles d'identifiant plus petit, pour que deux joueurs
  /// qui cherchent en même temps ne se rejoignent pas mutuellement.
  static Future<Map<String, dynamic>?> joinWaiting(String gameId, {String? below}) async {
    final since = DateTime.now().toUtc().subtract(const Duration(seconds: 20)).toIso8601String();
    var q = sb
        .from('rooms')
        .select('id')
        .eq('game', gameId)
        .eq('status', 'waiting')
        .eq('state->>quick', 'true')
        .isFilter('guest', null)
        .neq('host', user!.id)
        .gte('created_at', since);
    if (below != null) q = q.lt('id', below);
    final rows = await q.order('created_at').limit(5);
    for (final r in rows) {
      final got = await sb
          .from('rooms')
          .update({'guest': user!.id, 'status': 'playing'})
          .eq('id', r['id'])
          .eq('status', 'waiting')
          .isFilter('guest', null)
          .select();
      if (got.isNotEmpty) return got.first;
    }
    return null;
  }

  /// Retire ma salle d'attente. Renvoie false si quelqu'un l'a rejoint entre-temps.
  static Future<bool> removeWaiting(String id) async {
    final gone = await sb.from('rooms').delete().eq('id', id).eq('status', 'waiting').isFilter('guest', null).select();
    return gone.isNotEmpty;
  }

  static Future<void> finishRoom(String id) async {
    try {
      await sb.from('rooms').update({'status': 'finished'}).eq('id', id);
    } catch (_) {}
  }

  /// Rejoint une salle en attente avec son code. Renvoie null si introuvable.
  static Future<Map<String, dynamic>?> joinRoom(String code) async {
    final rows = await sb
        .from('rooms')
        .update({'guest': user!.id, 'status': 'playing'})
        .eq('code', code.trim().toUpperCase())
        .eq('status', 'waiting')
        .neq('host', user!.id)
        .isFilter('guest', null)
        .select();
    return rows.isEmpty ? null : rows.first;
  }

  static Future<void> deleteRoom(String id) async {
    try {
      await sb.from('rooms').delete().eq('id', id);
    } catch (_) {}
  }

  /// Une victoire = 1 point pour ce jeu dans `scores` (user_id = utilisateur connecté).
  static Future<void> saveWin(String gameId) async {
    if (user == null) return;
    try {
      await sb.from('scores').insert({'game': gameId, 'score': 1});
    } catch (_) {}
  }
}

/// Attend qu'un adversaire rejoigne la salle (écoute la table en temps réel).
class OnlineLobby {
  final String roomId;
  late final RealtimeChannel _ch;

  OnlineLobby(this.roomId, void Function() onGuest) {
    _ch = sb
        .channel('lobby_$roomId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rooms',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'id', value: roomId),
          callback: (p) {
            if (p.newRecord['guest'] != null) onGuest();
          },
        )
        .subscribe();
    // Au cas où l'adversaire serait arrivé avant l'abonnement.
    sb.from('rooms').select('guest').eq('id', roomId).single().then((r) {
      if (r['guest'] != null) onGuest();
    }).catchError((_) {});
  }

  void close() => sb.removeChannel(_ch);
}

/// Lien de jeu en ligne : les coups sont écrits dans rooms.state.moves, et
/// l'adversaire les reçoit en temps réel. Chacun n'écrit que pendant son tour.
class OnlineLink implements GameLink {
  final String roomId;
  late final RealtimeChannel _ch;
  final String _me = OnlineService.user!.id;
  final List<Map<String, dynamic>> _moves = [];
  final List<Map<String, dynamic>> _pending = [];
  void Function(Map<String, dynamic>)? _handler;
  bool _closed = false;

  OnlineLink(this.roomId) {
    _ch = sb
        .channel('room_$roomId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'rooms',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'id', value: roomId),
          callback: (p) => _onRow(p.newRecord),
        )
        .subscribe();
  }

  @override
  set onMessage(void Function(Map<String, dynamic>)? handler) {
    _handler = handler;
    _flush();
  }

  void _emit(Map<String, dynamic> m) {
    _pending.add(m);
    _flush();
  }

  void _flush() {
    while (_handler != null && _pending.isNotEmpty) {
      _handler!(_pending.removeAt(0));
    }
  }

  void _onRow(Map<String, dynamic> row) {
    final all = ((row['state'] as Map?)?['moves'] as List? ?? const [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
    for (var i = _moves.length; i < all.length; i++) {
      if (all[i]['by'] != _me) {
        _emit({'type': 'move', 'move': Map<String, dynamic>.from(all[i]['m'] as Map)});
      }
    }
    if (all.length > _moves.length) {
      _moves
        ..clear()
        ..addAll(all);
    }
    if (row['status'] == 'finished' && !_closed) _emit({'type': 'closed'});
  }

  @override
  void send(Map<String, dynamic> msg) {
    if (_closed || msg['type'] != 'move') return;
    _moves.add({'by': _me, 'm': msg['move']});
    sb
        .from('rooms')
        .update({'state': {'moves': _moves}})
        .eq('id', roomId)
        .then((_) {}, onError: (_) {});
  }

  @override
  void close() {
    if (_closed) return;
    _closed = true;
    sb.removeChannel(_ch);
    sb.from('rooms').update({'status': 'finished'}).eq('id', roomId).then((_) {}, onError: (_) {});
  }
}
