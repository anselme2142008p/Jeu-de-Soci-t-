import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'online.dart';
import 'people.dart';
import 'terms.dart';

/// Profils, nationalité, photo de profil et joueurs IA (tables Supabase).
class Social {
  /// Les 30 joueurs IA (table ai_players, lisible par tout le monde).
  static Future<List<PlayerInfo>> aiPlayers() async {
    final rows = await sb.from('ai_players').select().order('id');
    return [
      for (final r in rows)
        PlayerInfo(
          name: r['username'] as String,
          country: r['country_code'] as String,
          emoji: r['avatar_emoji'] as String,
          color: colorFromHex(r['avatar_color'] as String),
          isBot: true,
          level: r['level'] as int,
          greeting: r['greeting'] as String,
          botId: r['id'] as int,
        )
    ];
  }

  static PlayerInfo _profile(Map<String, dynamic> r, {required bool me}) => PlayerInfo(
        name: r['username'] as String,
        country: r['country'] as String?,
        avatarUrl: r['avatar'] as String?,
        isMe: me,
      );

  static Future<PlayerInfo?> myInfo() async {
    final u = OnlineService.user;
    if (u == null) return null;
    final r = await sb.from('profiles').select('username, avatar, country').eq('id', u.id).maybeSingle();
    return r == null ? null : _profile(r, me: true);
  }

  /// [moi, adversaire] d'une salle en ligne.
  static Future<List<PlayerInfo?>> playersOf(String roomId) async {
    final room = await sb.from('rooms').select('host, guest').eq('id', roomId).single();
    final ids = [room['host'], room['guest']].whereType<String>().toList();
    final rows = await sb.from('profiles').select('id, username, avatar, country').inFilter('id', ids);
    PlayerInfo? me, opp;
    for (final r in rows) {
      final mine = r['id'] == OnlineService.user?.id;
      final p = _profile(r, me: mine);
      if (mine) {
        me = p;
      } else {
        opp = p;
      }
    }
    return [me, opp];
  }

  /// Le joueur a-t-il accepté la version actuelle du message d'explication ?
  static Future<bool> termsAccepted() async {
    final u = OnlineService.user;
    if (u == null) return false;
    final r = await sb.from('profiles').select('terms_version').eq('id', u.id).maybeSingle();
    return r != null && ((r['terms_version'] as int?) ?? 0) >= termsVersion;
  }

  static Future<void> acceptTerms() async {
    await sb.from('profiles').update({
      'terms_accepted_at': DateTime.now().toUtc().toIso8601String(),
      'terms_version': termsVersion,
    }).eq('id', OnlineService.user!.id);
  }

  static Future<void> updateProfile(String username, String? country) async {
    await sb.from('profiles').update({'username': username, 'country': country}).eq('id', OnlineService.user!.id);
  }

  /// Envoie la photo dans le dossier `avatars/<mon id>/` puis la rattache au profil.
  static Future<String> uploadAvatar(Uint8List bytes, String ext) async {
    final uid = OnlineService.user!.id;
    final e = ext == 'jpeg' ? 'jpg' : ext;
    final type = e == 'png' ? 'image/png' : (e == 'webp' ? 'image/webp' : 'image/jpeg');
    final path = '$uid/${DateTime.now().millisecondsSinceEpoch}.$e';
    await sb.storage.from('avatars').uploadBinary(path, bytes, fileOptions: FileOptions(contentType: type));
    final url = sb.storage.from('avatars').getPublicUrl(path);
    await sb.from('profiles').update({'avatar': url}).eq('id', uid);
    return url;
  }
}
