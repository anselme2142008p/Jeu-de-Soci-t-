import 'package:flutter/material.dart';

/// Couleur principale de l'application (écran de démarrage, boutons, accents).
const Color brand = Color(0xFF3B4CCA);
const Color brandDark = Color(0xFF2A3796);

/// Mode d'affichage : suit le téléphone par défaut ; le bouton lune/soleil de l'accueil le change.
final ValueNotifier<ThemeMode> themeMode = ValueNotifier(ThemeMode.system);

Future<void> loadTheme() async {}

Future<void> setThemeMode(ThemeMode m) async {
  themeMode.value = m;
}
