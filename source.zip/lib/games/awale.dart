import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

class _Sim {
  final List<int> p, sc;
  _Sim(this.p, this.sc);
}

/// Awalé (mancala) : 12 trous, 4 graines chacun, 25 graines capturées pour gagner.
/// Trous 0 à 5 = Sud (joueur 0), 6 à 11 = Nord (joueur 1). Coup = {'i': trou joué}.
class Awale extends BoardGame {
  List<int> _p = List.filled(12, 4);
  final List<int> _sc = [0, 0];
  int _cur = 0, _n = 0;
  int? _winner;
  bool _over = false;

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  bool _own(int pl, int i) => pl == 0 ? i < 6 : i >= 6;

  int _opp(List<int> p, int pl) {
    var s = 0;
    for (var k = 0; k < 12; k++) {
      if (!_own(pl, k)) s += p[k];
    }
    return s;
  }

  _Sim _sim(List<int> p0, List<int> sc0, int pl, int i) {
    final p = List<int>.from(p0), sc = List<int>.from(sc0);
    var n = p[i], j = i;
    p[i] = 0;
    while (n > 0) {
      j = (j + 1) % 12;
      if (j == i) continue;
      p[j]++;
      n--;
    }
    if (!_own(pl, j)) {
      final cap = <int>[];
      var k = j;
      while (!_own(pl, k) && (p[k] == 2 || p[k] == 3)) {
        cap.add(k);
        k = (k + 11) % 12;
      }
      final total = cap.fold<int>(0, (a, x) => a + p[x]);
      if (cap.isNotEmpty && total < _opp(p, pl)) {
        for (final x in cap) {
          sc[pl] += p[x];
          p[x] = 0;
        }
      }
    }
    return _Sim(p, sc);
  }

  List<int> _movesFor(List<int> p, List<int> sc, int pl) {
    final mine = [for (var i = 0; i < 12; i++) if (_own(pl, i) && p[i] > 0) i];
    if (_opp(p, pl) > 0) return mine;
    return mine.where((i) => _opp(_sim(p, sc, pl, i).p, pl) > 0).toList(); // il faut nourrir l'adversaire
  }

  @override
  List<Move> legalMoves() => _over ? [] : [for (final i in _movesFor(_p, _sc, _cur)) {'i': i}];

  @override
  void play(Move move) {
    final me = _cur, r = _sim(_p, _sc, me, move['i'] as int);
    _p = r.p;
    _sc[0] = r.sc[0];
    _sc[1] = r.sc[1];
    _n++;
    void fin() {
      _over = true;
      _winner = _sc[0] > _sc[1] ? 0 : (_sc[1] > _sc[0] ? 1 : null);
    }

    if (_sc[me] >= 25) {
      fin();
      return;
    }
    _cur = 1 - me;
    if (_movesFor(_p, _sc, _cur).isEmpty) {
      _sc[me] += _p.fold<int>(0, (a, v) => a + v);
      _p = List.filled(12, 0);
      fin();
    } else if (_n > 200) {
      fin();
    }
  }

  @override
  Move botMove(Random rnd) {
    final me = _cur, opp = 1 - me;
    double best = -1e9;
    var pick = -1;
    for (final i in _movesFor(_p, _sc, me)) {
      final r = _sim(_p, _sc, me, i), gain = r.sc[me] - _sc[me];
      var ob = 0;
      for (final mm in _movesFor(r.p, r.sc, opp)) {
        ob = max(ob, _sim(r.p, r.sc, opp, mm).sc[opp] - r.sc[opp]);
      }
      final v = gain * 10 - ob * 8 + rnd.nextDouble();
      if (v > best) {
        best = v;
        pick = i;
      }
    }
    return {'i': pick};
  }

  @override
  String describe() => 'Sud (trous 0 à 5) : ${_p.sublist(0, 6)} ; Nord (trous 6 à 11) : ${_p.sublist(6)} ; captures Sud ${_sc[0]}, Nord ${_sc[1]}.';

  @override
  Widget buildBoard(BuildContext context, {required bool canPlay, required void Function(Move) onMove}) {
    final mv = canPlay && !_over ? _movesFor(_p, _sc, _cur).toSet() : <int>{};
    Widget row(List<int> idx) => Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(color: const Color(0xFF8A5A2B), borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            for (final i in idx)
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: FilledButton(
                      onPressed: mv.contains(i) ? () => onMove({'i': i}) : null,
                      style: FilledButton.styleFrom(
                        shape: const CircleBorder(),
                        padding: EdgeInsets.zero,
                        backgroundColor: mv.contains(i) ? const Color(0xFFC98A3B) : const Color(0xFF5E3B18),
                        disabledBackgroundColor: const Color(0xFF5E3B18),
                        foregroundColor: Colors.white,
                        disabledForegroundColor: Colors.white,
                      ),
                      child: Text('${_p[i]}'),
                    ),
                  ),
                ),
              ),
          ]),
        );
    return Column(children: [
      const Text('Nord'),
      row([11, 10, 9, 8, 7, 6]),
      row([0, 1, 2, 3, 4, 5]),
      const Text('Sud'),
      const SizedBox(height: 8),
      Text('Captures — Sud : ${_sc[0]} · Nord : ${_sc[1]} (25 pour gagner)'),
    ]);
  }
}
