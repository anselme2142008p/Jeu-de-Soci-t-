import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Échecs (sans roque ni prise en passant ; le pion promu devient dame).
/// Coup = {'m': 'départ-arrivée'}, cases numérotées ligne * 8 + colonne. Blancs en bas = joueur 0.
class Chess extends BoardGame {
  List<List<String>> _b = [
    for (final s in ['rnbqkbnr', 'pppppppp', '        ', '        ', '        ', '        ', 'PPPPPPPP', 'RNBQKBNR'])
      s.split('').map((c) => c == ' ' ? '' : c).toList()
  ];
  int _cur = 0, _n = 0;
  int? _winner, _sel;
  bool _over = false;
  String _msg = '';

  static const _val = {'p': 100, 'n': 320, 'b': 330, 'r': 500, 'q': 900, 'k': 0};
  static const _glyph = {'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'};

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  static bool _white(String c) => c == c.toUpperCase();
  static int _own(String c) => c.isEmpty ? -1 : (_white(c) ? 0 : 1);
  static bool _in(int r, int c) => r >= 0 && r < 8 && c >= 0 && c < 8;

  /// Cases atteignables par la pièce en (r, c), sans tenir compte de l'échec. atk : cases attaquées (pions).
  List<int> _pseudo(List<List<String>> b, int r, int c, bool atk) {
    final ch = b[r][c], p = _own(ch), t = ch.toLowerCase(), out = <int>[];
    bool add(int rr, int cc) {
      if (!_in(rr, cc)) return false;
      final o = _own(b[rr][cc]);
      if (o == p) return false;
      out.add(rr * 8 + cc);
      return o == -1;
    }

    if (t == 'p') {
      final d = p == 0 ? -1 : 1, s = p == 0 ? 6 : 1;
      if (!atk && _in(r + d, c) && b[r + d][c].isEmpty) {
        out.add((r + d) * 8 + c);
        if (r == s && b[r + 2 * d][c].isEmpty) out.add((r + 2 * d) * 8 + c);
      }
      for (final dc in [-1, 1]) {
        if (_in(r + d, c + dc) && (atk || _own(b[r + d][c + dc]) == 1 - p)) out.add((r + d) * 8 + c + dc);
      }
    } else if (t == 'n') {
      for (final d in const [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]]) {
        add(r + d[0], c + d[1]);
      }
    } else if (t == 'k') {
      for (var a = -1; a <= 1; a++) {
        for (var e = -1; e <= 1; e++) {
          if (a != 0 || e != 0) add(r + a, c + e);
        }
      }
    } else {
      const dg = [[1, 1], [1, -1], [-1, 1], [-1, -1]], st = [[1, 0], [-1, 0], [0, 1], [0, -1]];
      for (final d in (t == 'b' ? dg : (t == 'r' ? st : [...dg, ...st]))) {
        var rr = r + d[0], cc = c + d[1];
        while (add(rr, cc)) {
          rr += d[0];
          cc += d[1];
        }
      }
    }
    return out;
  }

  bool _attacked(List<List<String>> b, int r, int c, int by) {
    for (var i = 0; i < 8; i++) {
      for (var j = 0; j < 8; j++) {
        if (_own(b[i][j]) != by) continue;
        if (_pseudo(b, i, j, true).contains(r * 8 + c)) return true;
      }
    }
    return false;
  }

  bool _inCheck(List<List<String>> b, int p) {
    final k = p == 0 ? 'K' : 'k';
    for (var r = 0; r < 8; r++) {
      for (var c = 0; c < 8; c++) {
        if (b[r][c] == k) return _attacked(b, r, c, 1 - p);
      }
    }
    return true;
  }

  List<List<String>> _apply(List<List<String>> b, int from, int to) {
    final nb = [for (final row in b) List<String>.from(row)];
    var ch = nb[from ~/ 8][from % 8];
    nb[from ~/ 8][from % 8] = '';
    if (ch.toLowerCase() == 'p' && (to ~/ 8 == 0 || to ~/ 8 == 7)) ch = _white(ch) ? 'Q' : 'q';
    nb[to ~/ 8][to % 8] = ch;
    return nb;
  }

  List<List<int>> _moves(List<List<String>> b, int p) {
    final out = <List<int>>[];
    for (var r = 0; r < 8; r++) {
      for (var c = 0; c < 8; c++) {
        if (_own(b[r][c]) != p) continue;
        for (final to in _pseudo(b, r, c, false)) {
          if (!_inCheck(_apply(b, r * 8 + c, to), p)) out.add([r * 8 + c, to]);
        }
      }
    }
    return out;
  }

  int _eval(List<List<String>> b, int p) {
    var s = 0;
    for (final row in b) {
      for (final ch in row) {
        if (ch.isEmpty) continue;
        s += (_own(ch) == p ? 1 : -1) * _val[ch.toLowerCase()]!;
      }
    }
    return s;
  }

  int _nega(List<List<String>> b, int p, int d, int a, int bt) {
    if (d == 0) return _eval(b, p);
    final mv = _moves(b, p);
    if (mv.isEmpty) return _inCheck(b, p) ? -9999 - d : 0;
    var best = -1000000000;
    for (final m in mv) {
      final v = -_nega(_apply(b, m[0], m[1]), 1 - p, d - 1, -bt, -a);
      if (v > best) best = v;
      if (best > a) a = best;
      if (a >= bt) break;
    }
    return best;
  }

  List<int> _parse(Move m) => (m['m'] as String).split('-').map(int.parse).toList();

  @override
  List<Move> legalMoves() => _over ? [] : [for (final m in _moves(_b, _cur)) {'m': '${m[0]}-${m[1]}'}];

  @override
  void play(Move move) {
    final m = _parse(move), me = _cur;
    _b = _apply(_b, m[0], m[1]);
    _sel = null;
    _n++;
    _cur = 1 - me;
    final has = _moves(_b, _cur).isNotEmpty, chk = _inCheck(_b, _cur);
    if (!has) {
      _over = true;
      _winner = chk ? me : null;
      _msg = chk ? 'Échec et mat !' : 'Pat : match nul.';
    } else if (_n > 300) {
      _over = true;
      _msg = 'Partie trop longue : match nul.';
    } else {
      _msg = chk ? 'Échec !' : '';
    }
  }

  @override
  Move botMove(Random rnd) {
    final me = _cur;
    double best = -1e18;
    List<int>? pick;
    for (final m in _moves(_b, me)) {
      final v = -_nega(_apply(_b, m[0], m[1]), 1 - me, 2, -1000000000, 1000000000) + rnd.nextDouble() * 8;
      if (v > best) {
        best = v;
        pick = m;
      }
    }
    return {'m': '${pick![0]}-${pick[1]}'};
  }

  @override
  String describe() =>
      '${[for (final row in _b) row.map((c) => c.isEmpty ? '.' : c).join(' ')].join('\n')}\n(majuscules = blancs, minuscules = noirs) $_msg';

  Widget _piece(String ch) {
    final w = _white(ch);
    return FittedBox(
      child: Padding(
        padding: const EdgeInsets.all(2),
        child: Text(
          '${_glyph[ch.toLowerCase()]}\uFE0E',
          style: TextStyle(
            fontSize: 34,
            color: w ? Colors.white : Colors.black87,
            shadows: w ? const [Shadow(color: Colors.black, blurRadius: 2), Shadow(color: Colors.black, blurRadius: 3)] : null,
          ),
        ),
      ),
    );
  }

  @override
  Widget buildBoard(BuildContext context, {required bool canPlay, required void Function(Move) onMove}) {
    return Column(children: [
      if (_msg.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(_msg)),
      StatefulBuilder(builder: (ctx, setS) {
        final all = canPlay && !_over ? _moves(_b, _cur) : <List<int>>[];
        final froms = {for (final m in all) m[0]};
        final dests = _sel == null ? <List<int>>[] : all.where((m) => m[0] == _sel).toList();
        final dset = {for (final m in dests) m[1]};
        return AspectRatio(
          aspectRatio: 1,
          child: GridView.count(
            crossAxisCount: 8,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              for (var i = 0; i < 64; i++)
                GestureDetector(
                  onTap: () {
                    if (dset.contains(i)) {
                      onMove({'m': '$_sel-$i'});
                    } else if (froms.contains(i)) {
                      setS(() => _sel = i);
                    }
                  },
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: ((i ~/ 8) + (i % 8)) % 2 == 1 ? const Color(0xFFB58863) : const Color(0xFFF0D9B5),
                      border: (_sel == i || dset.contains(i)) ? Border.all(color: Colors.indigo, width: 3) : null,
                    ),
                    child: _b[i ~/ 8][i % 8].isEmpty ? null : _piece(_b[i ~/ 8][i % 8]),
                  ),
                ),
            ],
          ),
        );
      }),
    ]);
  }
}
