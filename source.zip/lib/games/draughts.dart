import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Dames (règles anglaises) : prise obligatoire, rafles, pion promu en dame.
/// Coup = {'m': 'départ-étape-…-arrivée'} avec des cases numérotées ligne * 8 + colonne
/// (une chaîne, donc facile à envoyer par le réseau et à comparer).
class Draughts extends BoardGame {
  // -1 vide, 0 pion du joueur 0 (rouge, monte), 1 pion du joueur 1 (blanc, descend),
  // 2 dame du joueur 0, 3 dame du joueur 1.
  List<List<int>> _b = List.generate(
    8,
    (r) => List.generate(8, (c) => (r + c) % 2 == 1 ? (r < 3 ? 1 : (r > 4 ? 0 : -1)) : -1),
  );
  int _cur = 0;
  int? _winner;
  bool _over = false;
  int _idle = 0; // coups de dame sans prise (match nul à 40)
  int? _sel; // case sélectionnée (affichage)

  static const _all = [[-1, -1], [-1, 1], [1, -1], [1, 1]];

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  List<List<int>> _dirs(int v, int p) =>
      v >= 2 ? _all : (p == 0 ? [[-1, -1], [-1, 1]] : [[1, -1], [1, 1]]);

  Move _mv(List<int> path) => {'m': path.join('-')};
  List<int> _cellsOf(Move m) => (m['m'] as String).split('-').map(int.parse).toList();

  void _jumps(List<List<int>> b, int r, int c, int v, int p, List<int> path, List<Move> out) {
    var found = false;
    for (final d in _dirs(v, p)) {
      final mr = r + d[0], mc = c + d[1], lr = r + 2 * d[0], lc = c + 2 * d[1];
      if (lr < 0 || lr > 7 || lc < 0 || lc > 7) continue;
      final m = b[mr][mc];
      if (m == -1 || (m & 1) == p || b[lr][lc] != -1) continue;
      found = true;
      b[mr][mc] = -1;
      final np = [...path, lr * 8 + lc];
      if (v < 2 && lr == (p == 0 ? 0 : 7)) {
        out.add(_mv(np)); // promotion : la rafle s'arrête
      } else {
        _jumps(b, lr, lc, v, p, np, out);
      }
      b[mr][mc] = m;
    }
    if (!found && path.length > 1) out.add(_mv(path));
  }

  List<Move> _gen(List<List<int>> b, int p) {
    final jumps = <Move>[], steps = <Move>[];
    for (var r = 0; r < 8; r++) {
      for (var c = 0; c < 8; c++) {
        final v = b[r][c];
        if (v == -1 || (v & 1) != p) continue;
        b[r][c] = -1;
        _jumps(b, r, c, v, p, [r * 8 + c], jumps);
        b[r][c] = v;
        for (final d in _dirs(v, p)) {
          final nr = r + d[0], nc = c + d[1];
          if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && b[nr][nc] == -1) {
            steps.add(_mv([r * 8 + c, nr * 8 + nc]));
          }
        }
      }
    }
    return jumps.isNotEmpty ? jumps : steps;
  }

  List<List<int>> _apply(List<List<int>> b, Move m) {
    final nb = [for (final row in b) List<int>.from(row)];
    final cells = _cellsOf(m);
    var v = nb[cells[0] ~/ 8][cells[0] % 8];
    nb[cells[0] ~/ 8][cells[0] % 8] = -1;
    for (var i = 1; i < cells.length; i++) {
      final r0 = cells[i - 1] ~/ 8, c0 = cells[i - 1] % 8, r1 = cells[i] ~/ 8, c1 = cells[i] % 8;
      if ((r1 - r0).abs() == 2) nb[(r0 + r1) ~/ 2][(c0 + c1) ~/ 2] = -1;
    }
    final tr = cells.last ~/ 8, tc = cells.last % 8;
    if (v < 2 && tr == ((v & 1) == 0 ? 0 : 7)) v += 2;
    nb[tr][tc] = v;
    return nb;
  }

  int _mat(List<List<int>> b, int p) {
    var s = 0;
    for (final row in b) {
      for (final v in row) {
        if (v == -1) continue;
        s += ((v & 1) == p ? 1 : -1) * (v >= 2 ? 2 : 1);
      }
    }
    return s;
  }

  @override
  List<Move> legalMoves() => _over ? [] : _gen(_b, _cur);

  @override
  void play(Move move) {
    final me = _cur, cells = _cellsOf(move);
    final v = _b[cells[0] ~/ 8][cells[0] % 8];
    final capture = (cells[1] ~/ 8 - cells[0] ~/ 8).abs() == 2;
    _idle = (capture || v < 2) ? 0 : _idle + 1;
    _b = _apply(_b, move);
    _sel = null;
    _cur = 1 - me;
    if (_gen(_b, _cur).isEmpty) {
      _over = true;
      _winner = me;
    } else if (_idle >= 40) {
      _over = true;
    }
  }

  @override
  Move botMove(Random rnd) {
    final me = _cur;
    double best = -1e9;
    Move? pick;
    for (final m in legalMoves()) {
      final nb = _apply(_b, m), rep = _gen(nb, 1 - me);
      var worst = rep.isEmpty ? 100.0 : 1e9;
      for (final x in rep) {
        worst = min(worst, _mat(_apply(nb, x), me).toDouble());
      }
      final v = worst + rnd.nextDouble() * 0.4;
      if (v > best) {
        best = v;
        pick = m;
      }
    }
    return pick!;
  }

  @override
  String describe() => [for (final row in _b) row.map((v) => v == -1 ? '.' : 'rbRB'[v]).join(' ')].join('\n');

  @override
  Widget buildBoard(BuildContext context,
      {required bool canPlay, required void Function(Move) onMove}) {
    return StatefulBuilder(builder: (ctx, setS) {
      final all = canPlay ? legalMoves() : <Move>[];
      final froms = {for (final m in all) _cellsOf(m).first};
      final dests = _sel == null ? <Move>[] : all.where((m) => _cellsOf(m).first == _sel).toList();
      final dset = {for (final m in dests) _cellsOf(m).last};
      return AspectRatio(
        aspectRatio: 1,
        child: GridView.count(
          crossAxisCount: 8,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            for (var i = 0; i < 64; i++)
              GestureDetector(
                onTap: () {
                  if (dset.contains(i)) {
                    onMove(dests.firstWhere((m) => _cellsOf(m).last == i));
                  } else if (froms.contains(i)) {
                    setS(() => _sel = i);
                  }
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: ((i ~/ 8) + (i % 8)) % 2 == 1 ? const Color(0xFFB58863) : const Color(0xFFF0D9B5),
                    border: (_sel == i || dset.contains(i)) ? Border.all(color: Colors.indigo, width: 3) : null,
                  ),
                  child: _b[i ~/ 8][i % 8] == -1 ? null : _piece(_b[i ~/ 8][i % 8]),
                ),
              ),
          ],
        ),
      );
    });
  }

  Widget _piece(int v) {
    final red = (v & 1) == 0;
    return Center(
      child: FractionallySizedBox(
        widthFactor: .76,
        heightFactor: .76,
        child: DecoratedBox(
          decoration: BoxDecoration(shape: BoxShape.circle, color: red ? const Color(0xFFC0392B) : const Color(0xFFF4F1E8)),
          child: v >= 2
              ? Center(child: Text('♛', style: TextStyle(fontSize: 18, color: red ? Colors.white : Colors.black87)))
              : null,
        ),
      ),
    );
  }
}
