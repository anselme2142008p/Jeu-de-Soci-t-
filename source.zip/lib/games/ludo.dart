import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Ludo (petits chevaux), 2 à 4 joueurs : 4 pions chacun, il faut un 6 pour sortir, un 6 fait rejouer,
/// un pion qui tombe sur un adversaire le renvoie à la maison. Il faut tomber pile pour arriver.
/// Coups : {'r': valeur du dé} puis {'p': numéro du pion} (le dé fait partie du coup, donc tout le monde voit la même partie).
class Ludo extends BoardGame {
  static const _cols = [Color(0xFFD93A3A), Color(0xFF2F6FDB), Color(0xFF2E9E4F), Color(0xFFF0B429)];
  static const _names = ['rouge', 'bleu', 'vert', 'jaune'];

  int _np = 2, _cur = 0, _die = 0; // _die = 0 : il faut lancer le dé
  // -1 maison, 0 à 39 case du circuit (depuis sa case de départ), 40 à 43 couloir final, 44 arrivé
  List<List<int>> _pos = [List.filled(4, -1), List.filled(4, -1)];
  int? _winner;
  bool _over = false;
  String _msg = '';

  @override
  void setPlayers(int n) {
    _np = n;
    _pos = [for (var i = 0; i < n; i++) List.filled(4, -1)];
    _cur = 0;
    _die = 0;
  }

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  int _color(int p) => _np == 2 ? p * 2 : p;
  int _start(int p) => _color(p) * 10;

  List<int> _movable() {
    final out = <int>[];
    for (var k = 0; k < 4; k++) {
      final p = _pos[_cur][k];
      if (p == -1) {
        if (_die == 6) out.add(k);
      } else if (p < 44 && p + _die <= 44) {
        out.add(k);
      }
    }
    return out;
  }

  int _captures(int pl, int t) {
    if (t < 0 || t > 39) return 0;
    final abs = (_start(pl) + t) % 40;
    var n = 0;
    for (var q = 0; q < _np; q++) {
      if (q == pl) continue;
      for (final pq in _pos[q]) {
        if (pq >= 0 && pq <= 39 && (_start(q) + pq) % 40 == abs) n++;
      }
    }
    return n;
  }

  @override
  List<Move> legalMoves() {
    if (_over) return [];
    if (_die == 0) return [for (var d = 1; d <= 6; d++) {'r': d}];
    return [for (final k in _movable()) {'p': k}];
  }

  @override
  void play(Move move) {
    final who = 'J${_cur + 1} (${_names[_color(_cur)]})';
    if (move.containsKey('r')) {
      _die = move['r'] as int;
      _msg = '$who lance $_die';
      if (_movable().isEmpty) {
        _msg += ' : aucun pion ne peut bouger.';
        final again = _die == 6;
        _die = 0;
        if (!again) _cur = (_cur + 1) % _np;
      }
      return;
    }
    final k = move['p'] as int, p = _pos[_cur][k], t = p == -1 ? 0 : p + _die;
    _pos[_cur][k] = t;
    var cap = 0;
    if (t <= 39) {
      final abs = (_start(_cur) + t) % 40;
      for (var q = 0; q < _np; q++) {
        if (q == _cur) continue;
        for (var j = 0; j < 4; j++) {
          final pq = _pos[q][j];
          if (pq >= 0 && pq <= 39 && (_start(q) + pq) % 40 == abs) {
            _pos[q][j] = -1;
            cap++;
          }
        }
      }
    }
    _msg = '$who joue le pion ${k + 1}${cap > 0 ? ' et renvoie $cap pion${cap > 1 ? 's' : ''} à la maison !' : '.'}';
    final six = _die == 6;
    _die = 0;
    if (_pos[_cur].every((x) => x == 44)) {
      _over = true;
      _winner = _cur;
      return;
    }
    if (!six) _cur = (_cur + 1) % _np;
  }

  @override
  Move botMove(Random rnd) {
    if (_die == 0) return {'r': 1 + rnd.nextInt(6)};
    double best = -1e9;
    var pick = _movable().first;
    for (final k in _movable()) {
      final p = _pos[_cur][k], t = p == -1 ? 0 : p + _die;
      var sc = t / 10 + rnd.nextDouble();
      if (t == 44) {
        sc += 90;
      } else if (t >= 40) {
        sc += 40;
      }
      if (p == -1) sc += 50;
      sc += 100.0 * _captures(_cur, t);
      if (sc > best) {
        best = sc;
        pick = k;
      }
    }
    return {'p': pick};
  }

  @override
  String describe() => 'Ludo : ${[for (var i = 0; i < _np; i++) 'J${i + 1} ${_pos[i].where((x) => x == 44).length}/4 arrivés'].join(', ')}. $_msg';

  @override
  Widget buildBoard(BuildContext context, {required bool canPlay, required void Function(Move) onMove}) {
    final cs = Theme.of(context).colorScheme;
    final mov = canPlay && !_over && _die != 0 ? _movable().toSet() : <int>{};
    return Column(children: [
      AspectRatio(
        aspectRatio: 1,
        child: LayoutBuilder(builder: (ctx, bc) {
          final s = bc.maxWidth, c = s / 2, r = s * 0.36, cell = s * 0.055;
          Offset onRing(int a, double f) {
            final ang = 2 * pi * a / 40 - pi / 2;
            return Offset(c + r * f * cos(ang), c + r * f * sin(ang));
          }

          Widget disc(Offset o, double size, Color color, {Widget? child, Border? border}) => Positioned(
                left: o.dx - size / 2,
                top: o.dy - size / 2,
                width: size,
                height: size,
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: color, border: border),
                  child: child,
                ),
              );

          final under = <Widget>[];
          for (var a = 0; a < 40; a++) {
            final owner = a % 10 == 0 ? _cols[a ~/ 10] : null;
            under.add(disc(onRing(a, 1), cell, owner?.withOpacity(.55) ?? cs.secondaryContainer));
          }
          for (var p = 0; p < _np; p++) {
            for (var i = 0; i < 4; i++) {
              under.add(disc(onRing(_start(p), .8 - .16 * i), cell * .8, _cols[_color(p)].withOpacity(.35)));
            }
            final y = onRing(_start(p), 1.2);
            for (var k = 0; k < 4; k++) {
              under.add(disc(y + Offset((k % 2 == 0 ? -1 : 1) * cell * .6, (k < 2 ? -1 : 1) * cell * .6), cell * 1.1, _cols[_color(p)].withOpacity(.18)));
            }
          }
          final pawns = <Widget>[];
          for (var pass = 0; pass < 2; pass++) {
            for (var p = 0; p < _np; p++) {
              for (var k = 0; k < 4; k++) {
                final pos = _pos[p][k];
                final isMov = p == _cur && mov.contains(k);
                if (pos == 44 || (pass == 0) == isMov) continue;
                Offset o;
                if (pos == -1) {
                  o = onRing(_start(p), 1.2) + Offset((k % 2 == 0 ? -1 : 1) * cell * .6, (k < 2 ? -1 : 1) * cell * .6);
                } else if (pos >= 40) {
                  o = onRing(_start(p), .8 - .16 * (pos - 40));
                } else {
                  o = onRing((_start(p) + pos) % 40, 1) + Offset(k * 1.5, k * 1.5);
                }
                final size = cell * 1.15;
                pawns.add(Positioned(
                  left: o.dx - size / 2,
                  top: o.dy - size / 2,
                  width: size,
                  height: size,
                  child: GestureDetector(
                    onTap: isMov ? () => onMove({'p': k}) : null,
                    child: Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _cols[_color(p)],
                        border: Border.all(color: isMov ? Colors.white : Colors.black54, width: isMov ? 3 : 1),
                      ),
                      child: Text('${k + 1}', style: TextStyle(fontSize: cell * .5, color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ));
              }
            }
          }
          return Stack(clipBehavior: Clip.none, children: [
            ...under,
            Positioned(left: c - 26, top: c - 26, width: 52, height: 52, child: Center(child: Text(_die == 0 ? '🎲' : '$_die', style: const TextStyle(fontSize: 28)))),
            ...pawns,
          ]);
        }),
      ),
      const SizedBox(height: 8),
      if (_msg.isNotEmpty) Text(_msg, textAlign: TextAlign.center),
      const SizedBox(height: 4),
      Wrap(spacing: 12, children: [
        for (var p = 0; p < _np; p++)
          Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.circle, size: 12, color: _cols[_color(p)]),
            Text(' J${p + 1} : ${_pos[p].where((x) => x == 44).length}/4', style: Theme.of(context).textTheme.bodySmall),
          ]),
      ]),
      const SizedBox(height: 8),
      FilledButton(
        onPressed: canPlay && !_over && _die == 0 ? () => onMove({'r': Random().nextInt(6) + 1}) : null,
        child: Text(_die == 0 ? '🎲 Lancer le dé' : 'Touche un pion lumineux'),
      ),
    ]);
  }
}
