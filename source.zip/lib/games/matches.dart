import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Allumettes : 21 allumettes, on en prend 1 à 3, celui qui prend la dernière perd.
/// Coup = {'k': nombre prélevé}.
class Matches extends BoardGame {
  int _n = 21, _cur = 0;
  int? _winner;
  bool _over = false;

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  @override
  List<Move> legalMoves() => _over ? [] : [for (var k = 1; k <= 3 && k <= _n; k++) {'k': k}];

  @override
  void play(Move move) {
    _n -= move['k'] as int;
    if (_n == 0) {
      _over = true;
      _winner = 1 - _cur;
    } else {
      _cur = 1 - _cur;
    }
  }

  @override
  Move botMove(Random rnd) {
    final k = (_n - 1) % 4;
    return {'k': k >= 1 ? k : 1 + rnd.nextInt(min(3, _n))};
  }

  @override
  String describe() => 'Allumettes restantes : $_n (celui qui prend la dernière perd).';

  @override
  Widget buildBoard(BuildContext context, {required bool canPlay, required void Function(Move) onMove}) {
    return Column(children: [
      Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center, children: [
        for (var i = 0; i < _n; i++)
          Container(
            width: 8,
            height: 56,
            decoration: BoxDecoration(
              color: const Color(0xFFD9B26F),
              border: const Border(top: BorderSide(color: Color(0xFFE5484D), width: 4)),
            ),
          ),
      ]),
      const SizedBox(height: 16),
      Text('Restantes : $_n'),
      const SizedBox(height: 8),
      Wrap(spacing: 8, children: [
        for (var k = 1; k <= 3; k++)
          FilledButton.tonal(
            onPressed: canPlay && !_over && k <= _n ? () => onMove({'k': k}) : null,
            child: Text('Prendre $k'),
          ),
      ]),
    ]);
  }
}
