import 'dart:math';
import 'package:flutter/material.dart';
import '../core/board_game.dart';

/// Mémoire : 8 paires. Le joueur qui trouve une paire rejoue. Coup = {'i': numéro de carte}.
/// L'ordre des cartes vient d'une graine commune (voir seed) pour que les deux téléphones aient le même jeu.
class MemoryGame extends BoardGame {
  static const _faces = ['🍎', '🐶', '🚗', '⚽', '🌟', '🎈', '🐱', '🍕'];
  static List<String> _shuffled(Random r) => [..._faces, ..._faces]..shuffle(r);

  List<String> _e = _shuffled(Random());
  final List<bool> _ok = List.filled(16, false);
  final List<bool> _up = List.filled(16, false);
  final Map<int, String> _seen = {}; // ce que le joueur virtuel a vu (sa mémoire)
  List<int>? _pend;
  int? _first;
  List<int> _sc = [0, 0];
  int _np = 2;
  int _cur = 0;
  int? _winner;
  bool _over = false;
  String _msg = '';

  @override
  void seed(int s) => _e = _shuffled(Random(s));

  @override
  void setPlayers(int n) {
    _np = n;
    _sc = List.filled(n, 0);
    _cur = 0;
  }

  String _scoreText() => [for (var i = 0; i < _np; i++) 'J${i + 1} : ${_sc[i]}'].join(' · ');

  int? _leader() {
    final top = _sc.reduce(max);
    final lead = [for (var i = 0; i < _np; i++) if (_sc[i] == top) i];
    return lead.length == 1 ? lead.first : null;
  }

  @override
  int get currentPlayer => _cur;
  @override
  bool get isOver => _over;
  @override
  int? get winner => _winner;

  @override
  List<Move> legalMoves() => _over ? [] : [for (var i = 0; i < 16; i++) if (!_ok[i] && i != _first) {'i': i}];

  @override
  bool isLegal(Move move) {
    final i = move['i'];
    return !_over && i is int && i >= 0 && i < 16 && !_ok[i] && i != _first;
  }

  @override
  void play(Move move) {
    if (_pend != null) {
      for (final k in _pend!) {
        _up[k] = false;
      }
      _pend = null;
    }
    final i = move['i'] as int;
    _up[i] = true;
    _seen[i] = _e[i];
    _msg = '';
    if (_first == null) {
      _first = i;
      return;
    }
    final a = _first!;
    _first = null;
    if (_e[a] == _e[i]) {
      _ok[a] = true;
      _ok[i] = true;
      _seen.remove(a);
      _seen.remove(i);
      _sc[_cur]++;
      _msg = 'Paire trouvée ! Il rejoue.';
      if (_ok.every((x) => x)) {
        _over = true;
        _winner = _leader();
      }
    } else {
      _pend = [a, i];
      _msg = 'Raté… retiens ces cartes !';
      _cur = (_cur + 1) % _np;
    }
  }

  @override
  Move botMove(Random rnd) {
    final mv = [for (final m in legalMoves()) m['i'] as int];
    bool rem() => rnd.nextDouble() > 0.25; // il oublie parfois
    if (_first != null) {
      final e = _e[_first!];
      for (final i in mv) {
        if (_seen[i] == e && rem()) return {'i': i};
      }
    } else {
      for (final i in mv) {
        for (final j in mv) {
          if (i < j && _seen[i] != null && _seen[i] == _seen[j] && rem()) return {'i': i};
        }
      }
    }
    final unk = mv.where((i) => _seen[i] == null).toList();
    final pool = unk.isNotEmpty ? unk : mv;
    return {'i': pool[rnd.nextInt(pool.length)]};
  }

  @override
  String describe() => 'Paires trouvées : ${_scoreText()}. $_msg';

  @override
  Widget buildBoard(BuildContext context, {required bool canPlay, required void Function(Move) onMove}) {
    final cs = Theme.of(context).colorScheme;
    return Column(children: [
      Text('Paires — ${_scoreText()}'),
      if (_msg.isNotEmpty) Text(_msg, textAlign: TextAlign.center),
      const SizedBox(height: 8),
      GridView.count(
        crossAxisCount: 4,
        shrinkWrap: true,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          for (var i = 0; i < 16; i++)
            GestureDetector(
              onTap: canPlay && !_over && !_ok[i] && i != _first ? () => onMove({'i': i}) : null,
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: (_up[i] || _ok[i]) ? cs.secondaryContainer : cs.primary,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Opacity(
                  opacity: _ok[i] ? .45 : 1,
                  child: Text((_up[i] || _ok[i]) ? _e[i] : '?', style: TextStyle(fontSize: 28, color: (_up[i] || _ok[i]) ? null : cs.onPrimary)),
                ),
              ),
            ),
        ],
      ),
    ]);
  }
}
