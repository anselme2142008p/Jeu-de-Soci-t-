import 'package:flutter/material.dart';
import '../core/board_game.dart';
import 'connect4.dart';
import 'draughts.dart';
import 'othello.dart';
import 'tictactoe.dart';

/// Pour ajouter un jeu : créer sa classe (extends BoardGame)
/// puis ajouter une ligne ici. Le menu, le bot, le LAN et le mode en ligne suivent.
final List<GameDef> allGames = [
  GameDef(
    id: 'tictactoe',
    title: 'Morpion',
    subtitle: 'Aligne 3 symboles',
    icon: Icons.grid_3x3,
    minPlayers: 2,
    maxPlayers: 2,
    create: TicTacToe.new,
  ),
  GameDef(
    id: 'connect4',
    title: 'Puissance 4',
    subtitle: 'Aligne 4 jetons',
    icon: Icons.view_column,
    minPlayers: 2,
    maxPlayers: 2,
    create: ConnectFour.new,
  ),
  GameDef(
    id: 'othello',
    title: 'Othello',
    subtitle: 'Retourne les pions adverses',
    icon: Icons.circle,
    minPlayers: 2,
    maxPlayers: 2,
    create: Othello.new,
  ),
  GameDef(
    id: 'draughts',
    title: 'Dames',
    subtitle: 'Capture tous les pions adverses',
    icon: Icons.grid_on,
    minPlayers: 2,
    maxPlayers: 2,
    create: Draughts.new,
  ),
];

GameDef? gameById(String id) {
  for (final g in allGames) {
    if (g.id == id) return g;
  }
  return null;
}
