import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/online.dart';
import 'core/theme.dart';
import 'screens/splash.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);
  await loadTheme();
  runApp(const JeuxApp());
}

class JeuxApp extends StatelessWidget {
  const JeuxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeMode,
      builder: (_, mode, __) => MaterialApp(
        title: 'Rotegan',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: brand, useMaterial3: true),
        darkTheme: ThemeData(colorSchemeSeed: brand, brightness: Brightness.dark, useMaterial3: true),
        themeMode: mode,
        // Évite des textes énormes si le téléphone a une très grande taille de police.
        builder: (context, child) => MediaQuery.withClampedTextScaling(
          minScaleFactor: 0.9,
          maxScaleFactor: 1.1,
          child: child!,
        ),
        home: const SplashScreen(),
      ),
    );
  }
}
