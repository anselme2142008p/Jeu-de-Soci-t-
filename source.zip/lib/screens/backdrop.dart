import 'dart:math';
import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Arrière-plan animé : de petits motifs (dés, pions…) flottent lentement derrière le contenu.
/// Très discret (10 % d'opacité), et immobile si le téléphone demande de réduire les animations.
class AnimatedBackdrop extends StatefulWidget {
  final List<String> motifs;
  final Widget child;
  final bool onBrand; // true : sur fond de la couleur principale (écran de démarrage)
  const AnimatedBackdrop({super.key, required this.motifs, required this.child, this.onBrand = false});

  @override
  State<AnimatedBackdrop> createState() => _AnimatedBackdropState();
}

class _Bit {
  final double x, y, size, phase;
  final int speed; // nombre de traversées par cycle (entier : la boucle est continue)
  const _Bit(this.x, this.y, this.size, this.phase, this.speed);
}

class _AnimatedBackdropState extends State<AnimatedBackdrop> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 60));
  late final List<_Bit> _bits = () {
    final r = Random(11);
    return [for (var i = 0; i < 16; i++) _Bit(r.nextDouble(), r.nextDouble(), 22 + r.nextDouble() * 30, r.nextDouble(), 1 + i % 3)];
  }();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.of(context).disableAnimations) {
      _c.stop();
    } else if (!_c.isAnimating) {
      _c.repeat();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final ink = widget.onBrand ? Colors.white : cs.onSurface;
    return Stack(children: [
      Positioned.fill(
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: widget.onBrand ? [brand, brandDark] : [cs.surface, Color.alphaBlend(cs.primary.withOpacity(.08), cs.surface)],
            ),
          ),
        ),
      ),
      Positioned.fill(
        child: IgnorePointer(
          child: RepaintBoundary(
            child: Opacity(
              opacity: widget.onBrand ? .16 : .10,
              child: AnimatedBuilder(
                animation: _c,
                builder: (ctx, _) => LayoutBuilder(builder: (ctx, bc) {
                  final t = _c.value;
                  return Stack(children: [
                    for (var i = 0; i < _bits.length; i++)
                      () {
                        final b = _bits[i];
                        final a = 2 * pi * (t * b.speed + b.phase);
                        final x = ((b.x + sin(a) * .03) % 1.0) * bc.maxWidth;
                        final y = (1.0 - ((b.y + t * b.speed) % 1.0)) * bc.maxHeight;
                        return Positioned(
                          left: x - b.size / 2,
                          top: y - b.size / 2,
                          child: Transform.rotate(
                            angle: sin(a) * .4,
                            child: Text(widget.motifs[i % widget.motifs.length], style: TextStyle(fontSize: b.size, color: ink)),
                          ),
                        );
                      }(),
                  ]);
                }),
              ),
            ),
          ),
        ),
      ),
      widget.child,
    ]);
  }
}
