import 'dart:async';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'backdrop.dart';
import 'screens.dart';

/// Écran de démarrage : couleur principale de l'application, nom et signature. Se ferme tout seul (ou d'un toucher).
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();
  Timer? _t;
  bool _gone = false;

  @override
  void initState() {
    super.initState();
    _t = Timer(const Duration(milliseconds: 2800), _next);
  }

  void _next() {
    if (_gone || !mounted) return;
    _gone = true;
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 400),
      pageBuilder: (_, __, ___) => const HomeScreen(),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
    ));
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: brand,
      body: AnimatedBackdrop(
        onBrand: true,
        motifs: const ['🎲', '♟', '🎯', '🃏', '🏆'],
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: _next,
          child: SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _c, curve: Curves.easeOut),
              child: SizedBox(
                width: double.infinity,
                child: Column(children: [
                  const Spacer(flex: 3),
                  Container(
                    width: 96,
                    height: 96,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .16), borderRadius: BorderRadius.circular(28)),
                    child: const Icon(Icons.casino, size: 52, color: Colors.white),
                  ),
                  const SizedBox(height: 22),
                  const Text('Rotegan', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w700, letterSpacing: 1, color: Colors.white)),
                  const SizedBox(height: 6),
                  Text('Jeux de société, en ligne et hors ligne', style: TextStyle(fontSize: 13, color: Colors.white.withValues(alpha: .85))),
                  const Spacer(flex: 4),
                  Text('Développé par', style: TextStyle(fontSize: 11, color: Colors.white.withValues(alpha: .75))),
                  const SizedBox(height: 2),
                  const Text('E. Anselme Dossou-Yovo', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Colors.white)),
                  const SizedBox(height: 28),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
