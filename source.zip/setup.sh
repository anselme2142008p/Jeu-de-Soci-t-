#!/bin/sh
# Lancé par la construction après la création du projet Android : nom affiché sur le téléphone.
sed -i 's#android:label="[^"]*"#android:label="Rotegan"#' app_build/android/app/src/main/AndroidManifest.xml
